package main;

public class Verb extends Word {

    public Verb(){
        super();
    }
    public Verb(String welsh, String english, String wordType) {
        super(welsh, english, wordType);
    }
    @Override
    public String getType() {
        return "v";
    }
    @Override
    public String getWelsh() {
        return super.getWelsh();
    }

    @Override
    public void setWelsh(String welsh) {
        super.setWelsh(welsh);
    }

    @Override
    public String getEnglish() {
        return super.getEnglish();
    }

    @Override
    public void setEnglish(String english) {
        super.setEnglish(english);
    }

    @Override
    public void display(){
        System.out.println("English Meaning: to " + super.getEnglish() + "\nWelsh Meaning: " + super.getWelsh());



    }



}
