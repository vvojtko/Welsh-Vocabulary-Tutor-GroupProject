package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;
public class FlashcardsController extends HomeController implements Initializable {

    @FXML
    TextField textField;

    @FXML
    Button prev;

    ArrayList<Word> flashcardsWords = new ArrayList<Word>(10);
    public int counter = 0;

    @FXML
    public void nextFlashcard(ActionEvent event) throws IOException {
        if (counter < 9) {
            counter++;
            textField.setText(flashcardsWords.get(counter).getEnglish());
        } else {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You ran out of flashcards words!\n Press button 'PICK NEW FLASHCARDS' to get a new set of flashcards"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 550, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        }
    }

    @FXML
    void newSet(ActionEvent event) throws IOException {
        daSomeShit();
        counter = 0;
    }

    @FXML
    public void previousFlashcard(ActionEvent event) throws IOException {
        if (counter > 0) {
            counter--;
            textField.setText(flashcardsWords.get(counter).getEnglish());
        } else {

            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("No previous flashcards, go to next flashcards"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        }
    }

    @FXML
    public void translate(ActionEvent event) throws IOException {
        textField.setText(flashcardsWords.get(counter).getWelsh());

    }


    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    public void daSomeShit() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        dictionary.load("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json");
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //    ArrayList<Word> flashcardsWords = new ArrayList<Word>(10);
        //      System.out.println(randomSingleWordPicker().getEnglishMeaning());
        // System.out.println(flashcardsWords.toArray().toString());

        for (int i = 0; i < 10; i++) {
            flashcardsWords.add(i, randomSingleWordPicker());
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       daSomeShit();
        System.out.println("counter : " + counter + "word: " + flashcardsWords.get(counter).getEnglish());
        textField.setText(String.valueOf(flashcardsWords.get(counter).getEnglish()));

    }
}
