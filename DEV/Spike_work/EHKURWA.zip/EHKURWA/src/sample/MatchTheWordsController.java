package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import main.Dictionary;
import main.Word;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;

public class MatchTheWordsController extends FlashcardsController implements Initializable {

    String answerr;
    ArrayList<Word> flashcardsWords = new ArrayList<Word>(6);


    @FXML
    Button answer1;
    @FXML
    Button answer2;
    @FXML
    Button answer3;
    @FXML
    Button answer4;
    @FXML
    Button answer5;
    @FXML
    Button answer6;
    @FXML
    Button answer7;
    @FXML
    Button answer8;


 //   ArrayList<Word> flashcardsWords = new ArrayList<Word>(10);
   // public int counter = 0;


    @FXML
    HBox hbox;

    @FXML
    public void check12(ActionEvent event) throws IOException{
        if(answerr.equals(answer2.getText())){

            answer2.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            System.out.println("git");
        }else{
            answer2.setStyle("-fx-background-color:#f23106");

            System.out.println("wrong");
        }
    }
    @FXML
    public void check13(ActionEvent event) throws IOException{
        if(answerr.equals(answer3.getText())){

            answer3.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            System.out.println("git");
        }else{
            answer3.setStyle("-fx-background-color:#f23106");
            System.out.println("wrong");
        }
    }
    @FXML
    public void check14(ActionEvent event) throws IOException{
        if(answerr.equals(answer4.getText())){

            answer4.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            System.out.println("git");
        }else{
            answer4.setStyle("-fx-background-color:#f23106");

            System.out.println("wrong");
        }
    }
    @FXML
    public void check15(ActionEvent event) throws IOException{
        if(answerr.equals(answer5.getText())){

            answer5.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            System.out.println("git");
        }else{
            answer5.setStyle("-fx-background-color:#f23106");

            System.out.println("wrong");
        }
    }

    @FXML
    public void check16(ActionEvent event) throws IOException{
        if(answerr.equals(answer6.getText())){
          //  answer6.setStyle("-fx-base:#06f27c");
            answer6.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            System.out.println("git");
        }else{
            answer6.setStyle("-fx-background-color:#f23106");
            System.out.println("wrong");
        }
    }
    @FXML
    public void check17(ActionEvent event) throws IOException{
        if(answerr.equals(answer7.getText())){
            answer7.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            System.out.println("git");
        }else{
            answer7.setStyle("-fx-background-color:#f23106");
            System.out.println("wrong");
        }
    }
    public void resetButtonStyles(){
        answer1.setStyle("");
        answer2.setStyle("");
        answer3.setStyle("");
        answer4.setStyle("");
        answer5.setStyle("");
        answer6.setStyle("");
        answer7.setStyle("");
    }
    @FXML
    public void newSet(ActionEvent event) throws IOException {
        resetButtonStyles();
        daSomeShit();
        int x = (int) getRandomIntegerBetweenRange(0,5);
        answerr = flashcardsWords.get(x).getEnglish();
        answer1.setText(flashcardsWords.get(x).getWelsh());
        assignAnswers();
    }
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    public static double getRandomIntegerBetweenRange(double min, double max){
        int x = (int) ((Math.random()*((max-min)+1))+min);
        return x;
    }
    public void daSomeShit() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        dictionary.load("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json");
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //    ArrayList<Word> flashcardsWords = new ArrayList<Word>(10);
        //      System.out.println(randomSingleWordPicker().getEnglishMeaning());
        // System.out.println(flashcardsWords.toArray().toString());

        for (int i = 0; i < 6; i++) {
            flashcardsWords.add(i, randomSingleWordPicker());
        }
    }
    public void assignAnswers(){
        answer6.setText(flashcardsWords.get(0).getEnglish());
        answer2.setText(flashcardsWords.get(1).getEnglish());
        answer3.setText(flashcardsWords.get(2).getEnglish());
        answer4.setText(flashcardsWords.get(3).getEnglish());
        answer5.setText(flashcardsWords.get(4).getEnglish());
        answer7.setText(flashcardsWords.get(5).getEnglish());
        }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        daSomeShit();
        int x = (int) getRandomIntegerBetweenRange(0,5);
        answerr = flashcardsWords.get(x).getEnglish();
        answer1.setText(flashcardsWords.get(x).getWelsh());
        assignAnswers();

    }
}