import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.TreeMultimap;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Dictionary {

    //private HashMap<String,Word> dictionary;
    private HashMultimap<String, Word> dictionary;
    private HashMultimap<String, Word> dictionary2;
    private Scanner scan;

    public Dictionary() {
        scan = new Scanner(System.in);
    //    dictionary = new HashMap<String, Word>();
   //     dictionaryForSearch = dictionary.asMap();
        dictionary = HashMultimap.create();
        dictionary2 = HashMultimap.create();
    }

    public void storeNewWord(){

        Word word = new Words();
        System.out.print("Write The English Meaning");
        word.setEnglishMeaning(scan.next());
        System.out.print("Write The Welsh Meaning");
        word.setWelshMeaning(scan.next());

        dictionary.put(word.getEnglishMeaning(),word);
        System.out.println("Stored!");
    }


    public void storeNewVerb(){

        Verb word = new Verb();
        System.out.print("Write The English Meaning");
        word.setEnglishMeaning(scan.next());
        System.out.print("Write The Welsh Meaning");
        word.setWelshMeaning(scan.next());


        dictionary.put(word.getEnglishMeaning(),word);
    }

    public void storeNewNoun(){

        Noun word = new Noun();
        System.out.print("Write The English Meaning");
        word.setEnglishMeaning(scan.next());
        System.out.print("Write The Welsh Meaning");
        word.setWelshMeaning(scan.next());
        System.out.print("Write The Welsh Gender");
        word.setGender(scan.next());

        dictionary.put(word.getEnglishMeaning(),word);
    }
    public void load(String fileName) {

        //variables
        String english = "";
        String welsh = "";
        String type = "";

        //parser
        JSONParser parser = new JSONParser();
        try {
            Object fileObj = parser.parse(new FileReader(fileName));
            JSONArray obj = (JSONArray) fileObj;
            Iterator<JSONObject> iterator = obj.iterator();
            //goes through all the objects
            while (iterator.hasNext()) {
                JSONObject object = iterator.next();
                english = (String) object.get("english");
                welsh = (String) object.get("welsh");

                //Word class is missing type - later we need to add it
                type = (String) object.get("wordType");
                System.out.println("English: " + english + "\nWelsh: " + welsh + "\nWordType: " + type + "\n");
                // adds creates new object and adds it to the words ArrayList
                if(type.equals("nm") || type.equals("nf")) {
                    Noun word = new Noun();
                    word.setEnglishMeaning(english);
                    word.setWelshMeaning(welsh);
                    word.setGender(type);
                    dictionary.put(word.getEnglishMeaning(),word);
                }
                else if (type.equals("v")) {
                    Verb word = new Verb();
                    word.setEnglishMeaning(english);
                    word.setWelshMeaning(welsh);
                    dictionary.put(word.getEnglishMeaning(),word);
                }else if(type.equals("other")) {
                    Word word = new Words();
                    word.setEnglishMeaning(english);
                    word.setWelshMeaning(welsh);
                    dictionary.put(word.getEnglishMeaning(),word);
                }


            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static SortedMap<String, Word> getByPrefix(
            NavigableMap<String, Word> words, String prefix) {
        return words.subMap(prefix, prefix + Character.MAX_VALUE);
    }
    public void findWordInEnglish() throws NullPointerException{

            String word = scan.next();
            for (HashMap.Entry<String,Word> entry : dictionary.entries())
                if(entry.getKey().equals(word)) {
                    entry.getValue().display();
                }



    }

    //two methods below are responsible for search
    //it works but poorly, need to work on that
    //but first have to get know what does it work

    public void printP(){
        System.out.println(returnMap(dictionary.asMap(),"s"));
    }
    public Map<String, Collection<Word>> returnMap(
            Map<String, Collection<Word>> chuj, String prefix) {
        return ((NavigableMap<String, Collection<Word>>) dictionary.asMap()).subMap(prefix, prefix + Character.MAX_VALUE);
    }


    public void findWordInWelsh(){
        String word = scan.next();
        for (HashMap.Entry<String,Word> entry : dictionary.entries())
            if(entry.getValue().getWelshMeaning().equals(word)){
                entry.getValue().display();
            }



    }



    public void printMap(){
        System.out.println(dictionary.toString());

    }


}
