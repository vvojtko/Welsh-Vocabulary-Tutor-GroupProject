public class Noun extends Word {

    private String gender;


    @Override
    public String getWelshMeaning() {
        return super.getWelshMeaning();
    }

    @Override
    public void setWelshMeaning(String welshMeaning) {
        super.setWelshMeaning(welshMeaning);
    }

    @Override
    public String getEnglishMeaning() {
        return super.getEnglishMeaning();
    }

    @Override
    public void setEnglishMeaning(String englishMeaning) {
        super.setEnglishMeaning(englishMeaning);
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Noun(String welshMeaning, String englishMeaning,String gender) {
        setWelshMeaning(welshMeaning);
        setEnglishMeaning(englishMeaning);
        setGender(gender);;

    }

    public Noun() {
        super();
    }


    @Override
    public void display(){
        System.out.println( "English Meaning:" + super.getEnglishMeaning() + "\nWelsh Meaning: " + super.getWelshMeaning() +
                "\nGender: " + getGender());



    }



}
