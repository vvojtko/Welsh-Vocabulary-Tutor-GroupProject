public class Verb extends Word {

    public Verb(){
        super();
    }
    public Verb(String welshMeaning, String englishMeaning) {
        super(welshMeaning, englishMeaning);
    }

    @Override
    public String getWelshMeaning() {
        return super.getWelshMeaning();
    }

    @Override
    public void setWelshMeaning(String welshMeaning) {
        super.setWelshMeaning(welshMeaning);
    }

    @Override
    public String getEnglishMeaning() {
        return super.getEnglishMeaning();
    }

    @Override
    public void setEnglishMeaning(String englishMeaning) {
        super.setEnglishMeaning(englishMeaning);
    }

    @Override
    public void display(){
        System.out.println("English Meaning: to " + super.getEnglishMeaning() + "\nWelsh Meaning: " + super.getWelshMeaning());



    }



}
