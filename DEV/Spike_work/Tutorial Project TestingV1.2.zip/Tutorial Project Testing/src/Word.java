public abstract class Word implements Comparable<Word>{

    private String welshMeaning;
    private String englishMeaning;



    public String getWelshMeaning() {
        return welshMeaning;
    }

    public void setWelshMeaning(String welshMeaning) {
        this.welshMeaning = welshMeaning;
    }

    public String getEnglishMeaning() {
        return englishMeaning;
    }

    public void setEnglishMeaning(String englishMeaning) {
        this.englishMeaning = englishMeaning;
    }

    public Word(String welshMeaning, String englishMeaning) {
        this.welshMeaning = welshMeaning;
        this.englishMeaning = englishMeaning;
    }

    public Word() {

    }

    public void display(){
        System.out.println( "English Meaning: " + englishMeaning + "\nWelsh Meaning: " + welshMeaning);



    }

    public int compareTo(Word o){
        return this.getEnglishMeaning().compareTo(o.getEnglishMeaning());
    }
}
