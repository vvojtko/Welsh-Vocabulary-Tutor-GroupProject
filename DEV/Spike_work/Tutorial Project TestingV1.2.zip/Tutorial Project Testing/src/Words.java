public class Words extends Word {

    @Override
    public String getWelshMeaning() {
        return super.getWelshMeaning();
    }

    @Override
    public void setWelshMeaning(String welshMeaning) {
        super.setWelshMeaning(welshMeaning);
    }

    @Override
    public String getEnglishMeaning() {
        return super.getEnglishMeaning();
    }

    @Override
    public void setEnglishMeaning(String englishMeaning) {
        super.setEnglishMeaning(englishMeaning);
    }

    public Words(String welshMeaning, String englishMeaning) {
        super(welshMeaning, englishMeaning);
    }

    public Words() {
        super();
    }

    @Override
    public void display(){
        System.out.println( "English Meaning: " + super.getEnglishMeaning() + "\nWelsh Meaning: " + super.getWelshMeaning());



    }
}
