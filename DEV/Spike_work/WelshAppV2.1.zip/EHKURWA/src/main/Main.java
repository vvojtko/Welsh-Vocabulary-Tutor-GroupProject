package main;

import java.util.NavigableMap;
import java.util.Scanner;
import java.util.SortedMap;

public class Main {



    private Dictionary dictionary;
    private Scanner scan;


    public Main() {
        dictionary = new Dictionary();
        scan = new Scanner(System.in);
      //  dictionary.load("src/dictionary.json");
    }
    private void printMenu() {
        System.out.println("1 -  Add Word");
        System.out.println("2 -  Add Verb");
        System.out.println("3 -  Add Noun");
        System.out.println("4 -  Find a Word in Welsh ");
        System.out.println("5 -  Find a Word in English");
        System.out.println("6 -  Search box");
        System.out.println("7 -  ");
        System.out.println("8 -  ");
        System.out.println("9 -  ");
        System.out.println("10 -  ");
        System.out.println("q -  Quit");
    }
    private static SortedMap<String, Word> getByPrefix(
            NavigableMap<String, Word> words, String prefix) {
        return words.subMap(prefix, prefix + Character.MAX_VALUE);
    }
    private void runMenu() {
        dictionary.load("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json");
        String response;
        do {
            printMenu();
            System.out.println("Remember that entering a wrong input will take you back to the menu");
            System.out.println("What would you like to do:");
            scan = new Scanner(System.in);
            response = scan.nextLine().toUpperCase();
            switch (response) {
                case "1":
                    dictionary.storeNewWord();
                    break;
                case "2":
                    dictionary.storeNewVerb();
                    break;
                case "3":
                    dictionary.storeNewNoun();
                    break;
                case "4":
                    dictionary.findWordInWelsh();
                    break;
                case "5":
                    dictionary.findWordInEnglish();
                    break;
                case "6":
                    //prints all words starting with "S"
                 //   dictionary.printP();
                    break;
                case "7":

                    break;
                case "8":

                    break;
                case "9":

                    break;

                case "Q":
                    break;
                default:
                    System.out.println("Try again");
            }
        } while (!(response.equals("Q")));
    }

    public static void main(String args[]){



        Main main = new Main();
        main.runMenu();




    }





}
