package sample;
        import com.beust.jcommander.IDefaultProvider;
        import com.google.gson.*;
        import com.fasterxml.jackson.databind.ObjectMapper;
        import com.google.common.collect.HashMultimap;
        import javafx.collections.FXCollections;
        import javafx.collections.ObservableList;
        import javafx.collections.transformation.FilteredList;
        import javafx.collections.transformation.SortedList;
        import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.fxml.Initializable;
        import javafx.scene.control.*;
        import javafx.scene.control.cell.PropertyValueFactory;

        import java.io.*;

        import javafx.util.Callback;
        import main.*;
        import main.Dictionary;

        import java.net.URL;
        import java.util.*;

public class HomeController implements Initializable {
    boolean showPractiseList = false;
    private Dictionary dictionary;
    private Dictionary dictionary2;
    int numOfWords;
    Gson gson = new Gson();
    ArrayList<Word> randomWordsArrayList = new ArrayList<Word>(numOfWords);
    HashMultimap<String, Word> dictionaryMap;
    HashMultimap<String, Word> practiseMap = HashMultimap.create();
    ObjectMapper mapper = new ObjectMapper();
    ObservableList<Word> data = FXCollections.observableArrayList();
    ObservableList<Word> data2 = FXCollections.observableArrayList();
    ObservableList<Word> favWords = FXCollections.observableArrayList();
    //  ListView<Word> listViewOfWords = new ListView<>(data);
    // TextField filterField;
//    ObservableList<String, Word> data = FXCollections.observableHashMap();

    // @FXML private ListView listViewOfWords;

    @FXML
    public TableColumn<Word, Void> colBtn;
    @FXML
    private TextField filterField;
    @FXML
    private TableView<Word> tableView;
    @FXML
    private TableColumn<Word, String> eng;
    @FXML
    private TableColumn<Word, String> welsh;
    @FXML
    private TableColumn<Word, String> wordType;

    //=======second table============
    @FXML
    public TableColumn<Word, Void> colBtn2;
    @FXML
    private TextField filterField2;
    @FXML
    private TableView<Word> tableView2;
    @FXML
    private TableColumn<Word, String> eng2;
    @FXML
    private TableColumn<Word, String> welsh2;
    @FXML
    private TableColumn<Word, String> wordType2;


    @FXML public void engToWelsh(ActionEvent event) throws IOException {
         tableView.getSortOrder().setAll(eng);
    }
    @FXML public void welshToEng(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(welsh);
    }
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
     //   Main.showHelp();
//        practiseMap.toString();
    }
    @FXML
    public void setTableViewInVisible(ActionEvent event) throws IOException {
        if(showPractiseList == true) {
            tableView2.setVisible(false);
            showPractiseList = false;
        }else{
            tableView2.setVisible(true);
            showPractiseList = true;
        }
    }


    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    void removingButtons() throws NullPointerException {


        Callback<TableColumn<Word, Void>, TableCell<Word, Void>> cellFactory
                = new Callback<TableColumn<Word, Void>, TableCell<Word, Void>>() {
            @Override
            public TableCell<Word, Void> call(TableColumn<Word, Void> param) {
                final TableCell<Word, Void> cell = new TableCell<Word, Void>() {
                    final Button btn = new Button("-");

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {
                            btn.setOnAction(event -> {
                                Word word = getTableView().getItems().get(getIndex());
                                //   if (!favWords.contains(word)) {
                                    favWords.remove(word);
                                    practiseMap.removeAll(word.getEnglish());
                                    try {
                                        File file = new File("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/practiselist.json");
                                        FileWriter writer = new FileWriter(file);
                                        String wordd = gson.toJson(favWords);
                                        writer.write(wordd);
                                        writer.close();
                                    }catch (IOException e) {
                                        e.printStackTrace();
                                    }


                            });
                            setGraphic(btn);
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };

        dictionary2.loadPrac("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/practiselist.json");
        practiseMap = dictionary2.export();
        colBtn2.setCellFactory(cellFactory);
    }

    void addButtons() throws NullPointerException {

        Callback<TableColumn<Word, Void>, TableCell<Word, Void>> cellFactory
                = new Callback<TableColumn<Word, Void>, TableCell<Word, Void>>() {
            @Override
            public TableCell<Word, Void> call(TableColumn<Word, Void> param) {
                final TableCell<Word, Void> cell = new TableCell<Word, Void>() {
                    final Button btn = new Button("+");

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {
                            btn.setOnAction(event -> {
                                Word word = getTableView().getItems().get(getIndex());
                               if(!practiseMap.containsKey(word.getEnglish())){
                                   favWords.add(new Word(word.getEnglish(), word.getWelsh(), word.getType()));
                                   practiseMap.put(word.getEnglish(),new Word(word.getEnglish(),word.getEnglish(),word.getType()));

                                   try {
                                       File file = new File("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/practiselist.json");
                                       FileWriter writer = new FileWriter(file);
                                       String wordd = gson.toJson(favWords);
                                       writer.write(wordd);
                                       writer.close();
                                   }catch (IOException e) {
                                       e.printStackTrace();
                                   }

                                } else {
                                    System.out.println("spierdalaj");
                                }


                            });
                            setGraphic(btn);
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
    }

    public void daSomeShit() {

        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else if(wt == "nf"){
                data.add(new NounF(word.getEnglish(), word.getWelsh(), "nf"));
            } else if(wt.equals("nm")){
                data.add(new NounM(word.getEnglish(), word.getWelsh(), "nm"));
            } else {
                data.add(new Verb(word.getEnglish(),word.getWelsh(),wt));
            }
        }
        FilteredList<Word> filteredList = new FilteredList<>(data, p -> true);
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (word.getEnglish().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (word.getWelsh().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });

        SortedList<Word> sortedList = new SortedList<>(filteredList);

        sortedList.comparatorProperty().bind(tableView.comparatorProperty());
        tableView.setItems(sortedList);
    }
    public void daSomeShit2() {

        for (Map.Entry<String, Word> entry : practiseMap.entries()) {
            Word word = entry.getValue();
            System.out.println("p m: " + word);
            String wt = word.getType();
            if (wt == null) {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        FilteredList<Word> filteredList = new FilteredList<>(favWords, p -> true);
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (word.getEnglish().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (word.getWelsh().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });
        SortedList<Word> sortedList = new SortedList<>(filteredList);

        sortedList.comparatorProperty().bind(tableView2.comparatorProperty());

        tableView2.setItems(sortedList);

    }
    public Word randomSingleWordPicker() {
        double randomDouble = Math.random();
        randomDouble = randomDouble * 50 + 1;
        int randomInt = (int) randomDouble;
        Word w = new Word (data.get((randomInt * randomInt)%data.size()).getEnglish(),
                data.get((randomInt * randomInt)%data.size()).getWelsh(),
                data.get((randomInt * randomInt)%data.size()).getType());
        return w;
    }
    public ArrayList<Word> randomWordPicker(int numOfWords) {
        ArrayList<Word> randomWordsArrayList = new ArrayList<Word>(numOfWords);
        double randomDouble = Math.random();
        randomDouble = randomDouble * 50 + 1;
        int randomInt = (int) randomDouble;


        for (int i = 0; i < numOfWords; i++) {
            randomWordsArrayList.add(i,data.get(i * randomInt));
        }
            return randomWordsArrayList;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        dictionary.load("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json");
        dictionaryMap = dictionary.export();


        dictionary2 = new Dictionary();
        dictionary2.loadPrac("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/practiselist.json");
        practiseMap = dictionary2.export();


        daSomeShit();
        daSomeShit2();
       // System.out.println("prac map: " + favWords.toString());
        addButtons();
        removingButtons();
       // tableView.setStyle("-fx-background-color:#06f27c");
        //
        colBtn.setCellValueFactory(new PropertyValueFactory<Word, Void>("addButton"));
        welsh.setCellValueFactory(new PropertyValueFactory<Word, String>("english"));
        eng.setCellValueFactory(new PropertyValueFactory<Word, String>("welsh"));
        wordType.setCellValueFactory(new PropertyValueFactory<Word, String>("type"));
        colBtn2.setCellValueFactory(new PropertyValueFactory<Word, Void>("removingButton"));
        welsh2.setCellValueFactory(new PropertyValueFactory<Word, String>("welsh"));
        eng2.setCellValueFactory(new PropertyValueFactory<Word, String>("english"));
        wordType2.setCellValueFactory(new PropertyValueFactory<Word, String>("type"));
        tableView2.setVisible(showPractiseList);
    }
}


