package sample;

import javafx.application.Application;
import javafx.embed.swing.JFXPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import main.Dictionary;

import java.io.IOException;

public class Main extends Application {
    private static Stage primaryStage;
    private static GridPane mainLayout;

    @Override
    public void start(Stage primaryStage) throws Exception {
        Main.primaryStage = primaryStage;
        Main.primaryStage.setTitle("Welsh Learning App");
        showHome();

    }
    public static void showHome() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("HomeScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public static void showHelp() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("HelpScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void showAdd() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("AddWordsScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void showRevision() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("RevisionScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void showMatch() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("PickTheWordController.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void showTest() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("TestScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void showPick() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("MatchTheWords.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void showFlashcards() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("flashcards.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public static void main(String[] args) {
        launch(args);

    }

}
