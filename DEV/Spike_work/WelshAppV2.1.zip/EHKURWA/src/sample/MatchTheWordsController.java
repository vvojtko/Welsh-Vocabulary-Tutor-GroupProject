package sample;

import com.google.common.collect.HashMultimap;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class MatchTheWordsController extends  HomeController implements Initializable {


    HashMultimap<String, Word> dictionaryMap;
    int checker = 0;
    int score = 0;
    int words = 0;
    int random = 1;
    public Stack<String> answers = new Stack<String>();
    public List<Integer> numbers = new ArrayList<>();
    public ArrayList<Word> flashcardsWords = new ArrayList<Word>(4);
    String match1, match2, match3, match4, match5, match6, match7, match8 = "";

    //thinking that int variable might be helpful with getting idea which button was last clicked
    //but don't know how to implement it



    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    @FXML
    Button button1;
    @FXML
    Button button2;
    @FXML
    Button button3;
    @FXML
    Button button4;
    @FXML
    Button button5;
    @FXML
    Button button6;
    @FXML
    Button button7;
    @FXML
    Button button8;

    @FXML Button submit;

    @FXML
    Text showScore;

    public void submit() {
        if (checker==8) {
            checker = 0;
            correctChecker();
            daSomeShit();
            assignButtons();
            showScore.setText("Your score: " + score + "/" + words);
        }else{
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("Match all the words to submit!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        }
    }
    HashMap<String, Word> hashMapEnglish = new HashMap<>();
    HashMap<String, Word> hashMapWelsh = new HashMap<>();

    //this function is just loading data into list and pick 4 random words
    //then it puts it into flashcardsWords arraylist on which buttons and meaning works
    public void daSomeShit() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        dictionary.load("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json");
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        for (int i = 0; i < 4; i++) {
            Word w = new Word();
            w = randomSingleWordPicker();
            if(!flashcardsWords.contains(w)) {
                flashcardsWords.add(i, randomSingleWordPicker());
            }else{
                while(!flashcardsWords.contains(w)) {
                    w = randomSingleWordPicker();
                }
            }
        }
    }


    //assigns english and welsh meaning to buttons
    public void assignButtons(){
        Random randomGenerator = new Random();
        int b1 = 0;
        int b2 = 1;
        int b3 = 2;
        int b4 = 3;
        numbers.add(b1);
        numbers.add(b2);
        numbers.add(b3);
        numbers.add(b4);

        int randomInt0 = randomGenerator.nextInt(3);
        button1.setText(flashcardsWords.get(numbers.remove(randomInt0)).getEnglish());
        button1.setStyle("");

        randomInt0 = randomGenerator.nextInt(2);
        button2.setText(flashcardsWords.get(numbers.remove(randomInt0)).getEnglish());
        button2.setStyle("");

        randomInt0 = randomGenerator.nextInt(1);
        button3.setText(flashcardsWords.get(numbers.remove(randomInt0)).getEnglish());
        button3.setStyle("");

        randomInt0 = randomGenerator.nextInt(1);
        button4.setText(flashcardsWords.get(numbers.remove(randomInt0)).getEnglish());
        button4.setStyle("");
        int b5 = 0;
        int b6 = 1;
        int b7 = 2;
        int b8 = 3;
        numbers.add(b1);
        numbers.add(b2);
        numbers.add(b3);
        numbers.add(b4);
        int randomInt = randomGenerator.nextInt(3);
        button5.setText(flashcardsWords.get(numbers.remove(randomInt)).getWelsh());
        button5.setStyle("");
        randomInt = randomGenerator.nextInt(2);
        button6.setText(flashcardsWords.get(numbers.remove(randomInt)).getWelsh());
        button6.setStyle("");
        randomInt = randomGenerator.nextInt(1);
        button7.setText(flashcardsWords.get(numbers.remove(randomInt)).getWelsh());
        button7.setStyle("");
        randomInt = randomGenerator.nextInt(1);
        button8.setText(flashcardsWords.get(numbers.remove(randomInt)).getWelsh());
        button8.setStyle("");



        button1.setDisable(false);
        button2.setDisable(false);
        button3.setDisable(false);
        button4.setDisable(false);
        button5.setDisable(false);
        button6.setDisable(false);
        button7.setDisable(false);
        button8.setDisable(false);
    }




    //remember when you compare the buttons (words) you have to work on flashcard arraylist to compare if words matches
    //of course you can adjust code as you wish
    public void correctChecker(){

        Word m1 = new Word(flashcardsWords.get(0).getEnglish(), flashcardsWords.get(0).getWelsh(), flashcardsWords.get(0).getType());
        Word m2 = new Word(flashcardsWords.get(1).getEnglish(), flashcardsWords.get(1).getWelsh(), flashcardsWords.get(1).getType());
        Word m3 = new Word(flashcardsWords.get(2).getEnglish(), flashcardsWords.get(2).getWelsh(), flashcardsWords.get(2).getType());
        Word m4 = new Word(flashcardsWords.get(3).getEnglish(), flashcardsWords.get(3).getWelsh(), flashcardsWords.get(3).getType());

        hashMapEnglish.put(m1.getEnglish(), m1);
        hashMapEnglish.put(m2.getEnglish(), m2);
        hashMapEnglish.put(m3.getEnglish(), m3);
        hashMapEnglish.put(m4.getEnglish(), m4);
        hashMapWelsh.put(m1.getWelsh(),m1);
        hashMapWelsh.put(m2.getWelsh(),m2);
        hashMapWelsh.put(m3.getWelsh(),m3);
        hashMapWelsh.put(m4.getWelsh(),m4);

        String match12 = "0";
        String match34 = "0";
        String match56 = "0";
        String match78 = "0";

        match1 = answers.pop();
        match2 = answers.pop();
        match3 = answers.pop();
        match4 = answers.pop();
        match5 = answers.pop();
        match6 = answers.pop();
        match7 = answers.pop();
        match8 = answers.pop();


        if(hashMapEnglish.containsKey(match2) && hashMapWelsh.containsKey(match1) || hashMapEnglish.containsKey(match1) && hashMapWelsh.containsKey(match2)) {
            if(hashMapEnglish.containsKey(match2)) {
                if (hashMapEnglish.get(match2).getEnglish().equals(hashMapWelsh.get(match1).getEnglish())) {
                    score++;
                }
            }else if(hashMapEnglish.containsKey(match1)) {
                if (hashMapEnglish.get(match1).getEnglish().equals(hashMapWelsh.get(match2).getEnglish())) {
                    score++;
                }
            }else{
                    System.out.println("wrong");
                }
            }else{
            System.out.println("shiet");
        }
         //   }
        if(hashMapEnglish.containsKey(match4)&& hashMapWelsh.containsKey(match3) || hashMapEnglish.containsKey(match3) && hashMapWelsh.containsKey(match4) ) {
            if(hashMapEnglish.containsKey(match4)){
                if (hashMapEnglish.get(match4).getEnglish().equals(hashMapWelsh.get(match3).getEnglish())) {
                    score++;
            }else if(hashMapEnglish.containsKey(match3)){
                    if(hashMapEnglish.get(match3).getEnglish().equals(hashMapWelsh.get(match4).getEnglish())) {
                        score++;
                    }
            }else {
                System.out.println("wrong");
                }
            }
        }else{
            System.out.println("shiet");
        }
        if(hashMapEnglish.containsKey(match6)&& hashMapWelsh.containsKey(match5) || hashMapEnglish.containsKey(match5) && hashMapWelsh.containsKey(match6)) {
            if (hashMapEnglish.containsKey(match6)){
                if(hashMapEnglish.get(match6).getEnglish().equals(hashMapWelsh.get(match5).getEnglish())) {


                    score++;
                }
            }else if(hashMapEnglish.containsKey(match5)) {
                if (hashMapEnglish.get(match5).getEnglish().equals(hashMapWelsh.get(match6).getEnglish())) {
                    score++;
                }
            }else {
                System.out.println("wrong");
            }
        }else{
            System.out.println("shiet");
        }
        if(hashMapEnglish.containsKey(match8)&& hashMapWelsh.containsKey(match7) || hashMapEnglish.containsKey(match7) && hashMapWelsh.containsKey(match8)) {
            if (hashMapEnglish.containsKey(match8)) {
                if (hashMapEnglish.get(match8).getEnglish().equals(hashMapWelsh.get(match7).getEnglish())) {
                    score++;
                } else if (hashMapEnglish.containsKey(match7)) {
                    if (hashMapEnglish.get(match7).getEnglish().equals(hashMapWelsh.get(match8).getEnglish())) {
                        score++;
                    }
                } else {
                    System.out.println("wrong");
                }
            }
        }else{
            System.out.println("shiet");
        }
        words = words + 4;
 }

    //remember when you compare the buttons (words) you have to work on flashcard arraylist to compare if words matches
    //of course you can adjust code as you wish


    @Override
    public void initialize(URL location, ResourceBundle resources) {


        daSomeShit();   //loads data
        assignButtons();    //assign words to buttons


        button1.setOnAction(e -> {
            button1.setDisable(true);
            answers.push(button1.getText());
            if(checker < 2) {
                button1.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button1.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button1.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button1.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button2.setOnAction(e -> {
            button2.setDisable(true);
            answers.push(button2.getText());
            if(checker < 2) {
                button2.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button2.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button2.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button2.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button3.setOnAction(e -> {

            button3.setDisable(true);
            answers.push(button3.getText());
            if(checker < 2) {
                button3.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button3.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button3.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button3.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button4.setOnAction(e -> {

            button4.setDisable(true);
            answers.push(button4.getText());
            if(checker < 2) {
                button4.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button4.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button4.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button4.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button5.setOnAction(e -> {

            button5.setDisable(true);
            answers.push(button5.getText());
            if(checker < 2) {
                button5.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button5.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button5.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button5.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button6.setOnAction(e -> {

            button6.setDisable(true);
            answers.push(button6.getText());
            if(checker < 2) {
                button6.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button6.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button6.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button6.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button7.setOnAction(e -> {

            button7.setDisable(true);
            answers.push(button7.getText());
            if(checker < 2) {
                button7.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button7.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button7.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button7.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button8.setOnAction(e -> {
            button8.setDisable(true);
            answers.push(button8.getText());
            if(checker < 2) {
                button8.setStyle("-fx-background-color: #06f27c");
            }
            if(checker >= 2 && checker < 4) {
                button8.setStyle("-fx-background-color: #FF6347");
            }
            if(checker >= 4 && checker < 6) {
                button8.setStyle("-fx-background-color: #BA55D3");
            }
            if(checker >=6) {
                button8.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });

        showScore.setText("Your score: " + score + "/" + words);
    }

}
