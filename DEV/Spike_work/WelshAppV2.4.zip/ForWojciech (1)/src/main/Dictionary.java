package main;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.HashMultimap;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.io.IOException;
import java.util.*;

public class Dictionary {

    //private HashMap<String,Word> dictionary;
    private HashMultimap<String, Word> dictionary;
    private HashMultimap<String, Word> dictionary2;
    private String filename;
    private Scanner scan;
    ObjectMapper mapper = new ObjectMapper();

    public Dictionary() {
        scan = new Scanner(System.in);
        //    dictionary = new HashMap<String, Word>();
        //     dictionaryForSearch = dictionary.asMap();
        dictionary = HashMultimap.create();
        dictionary2 = HashMultimap.create();
    }

    public void storeNewWord() {

        Word word = new Other();
        System.out.print("Write The English Meaning");
        word.setEnglish(scan.next());
        System.out.print("Write The Welsh Meaning");
        word.setWelsh(scan.next());

        dictionary.put(word.getEnglish(), word);
        System.out.println("Stored!");
    }


    public void storeNewVerb() {

        Verb word = new Verb();
        System.out.print("Write The English Meaning");
        word.setEnglish(scan.next());
        System.out.print("Write The Welsh Meaning");
        word.setWelsh(scan.next());


        dictionary.put(word.getEnglish(), word);
    }

    public void storeNewNoun() {

        NounF word = new NounF();
        System.out.print("Write The English Meaning");
        word.setEnglish(scan.next());
        System.out.print("Write The Welsh Meaning");
        word.setWelsh(scan.next());

        dictionary.put(word.getEnglish(), word);
    }


    /*
        public void run() {

            InputStream is = AfterTest.class.getResourceAsStream("/dictionary.json");
            boolean success = false;
            System.out.println("Please enter filename:");
            String filename = scan.next();
            success = json.read(filename);

            while(!success) {
                System.err.println("\nFile not found. Please try again.");
              //  System.out.println("Please enter filename:");
                filename  = scan.next();
                success = json.read(filename);
            }

            dictionary = json.export();

            System.out.println(dictionary.toString());
            json.write(filename);
        }
        */
    public void load(String fileName) throws IOException, ParseException, FileNotFoundException, Exception {

        //variables
        String english = "";
        String welsh = "";
        String type = "";

        //parser
        JSONParser parser = new JSONParser();

            Object fileObj = parser.parse(new FileReader(fileName));
            JSONArray obj = (JSONArray) fileObj;
            Iterator<JSONObject> iterator = obj.iterator();
            //goes through all the objects
            while (iterator.hasNext()) {
                JSONObject object = iterator.next();
                english = (String) object.get("english");
                welsh = (String) object.get("welsh");
                //Word class is missing type - later we need to add it
                type = (String) object.get("wordType");
                // System.out.println("English: " + english + "\nWelsh: " + welsh + "\nWordType: " + type + "\n");
                // adds creates new object and adds it to the words ArrayList
                if (type.equals("nf")) {
                    NounF word = new NounF();
                    word.setEnglish(english);
                    word.setWelsh(welsh);

                    dictionary.put(word.getEnglish(), word);
                } else if (type.equals("nm")) {
                    NounM word = new NounM();
                    word.setEnglish(english);
                    word.setWelsh(welsh);

                    dictionary.put(word.getEnglish(), word);
                } else if (type.equals("v")) {
                    Verb word = new Verb();
                    word.setEnglish(english);
                    word.setWelsh(welsh);
                    dictionary.put(word.getEnglish(), word);
                } else if (type.equals("other")) {
                    Word word = new Other();
                    word.setEnglish(english);
                    word.setWelsh(welsh);
                    dictionary.put(word.getEnglish(), word);
                }


            }


        }



    public void loadPrac(String fileName) throws Exception,IOException,ParseException,FileNotFoundException{

        //variables
        String english = "";
        String welsh = "";
        String type = "";

        //parser
        JSONParser parser = new JSONParser();

            Object fileObj = parser.parse(new FileReader(fileName));
            JSONArray obj = (JSONArray) fileObj;
            Iterator<JSONObject> iterator = obj.iterator();
            //goes through all the objects
            while (iterator.hasNext()) {
                JSONObject object = iterator.next();
                welsh = (String) object.get("welsh");
                english = (String) object.get("english");
                type = (String) object.get("wordType");
                //  System.out.println("PRAC MAP!!");
                // System.out.println("English: " + english + "\nWelsh: " + welsh + "\nWordType: " + type + "\n");

                if (type.equals("nf")) {
                    NounF word = new NounF();
                    word.setEnglish(english);
                    word.setWelsh(welsh);

                    dictionary.put(word.getEnglish(), word);
                } else if (type.equals("nm")) {
                    NounM word = new NounM();
                    word.setEnglish(english);
                    word.setWelsh(welsh);

                    dictionary.put(word.getEnglish(), word);
                } else if (type.equals("other")) {
                    Word word = new Other();
                    word.setEnglish(english);
                    word.setWelsh(welsh);
                    dictionary.put(word.getEnglish(), word);
                } else {
                    Verb word = new Verb();
                    word.setEnglish(english);
                    word.setWelsh(welsh);
                    dictionary.put(word.getEnglish(), word);
                }


            }

    }

    public void write(String filename, HashMultimap<String, Word> mapName) {
        try {
            mapper.writeValue(new File(filename), mapName);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static SortedMap<String, Word> getByPrefix(
            NavigableMap<String, Word> words, String prefix) {
        return words.subMap(prefix, prefix + Character.MAX_VALUE);
    }

    public void findWordInEnglish() throws NullPointerException {

        String word = scan.nextLine();
        for (HashMap.Entry<String, Word> entry : dictionary.entries())
            if (entry.getKey().equals(word)) {
                entry.getValue().display();
            }


    }

    public HashMultimap<String, Word> export() {
        return dictionary;
    }

    public void findWordInWelsh() {
        String word = scan.next();
        for (HashMap.Entry<String, Word> entry : dictionary.entries())
            if (entry.getValue().getWelsh().equals(word)) {
                entry.getValue().display();
            }


    }

    public String findWordInEnglishDeveloper(String word) throws NullPointerException {

        for (HashMap.Entry<String, Word> entry : dictionary.entries())
            if (entry.getKey().equals(word)) {
                System.out.println(entry.getValue().toString());
                return entry.getValue().toString();
            }

        return null;
    }

    public String findWordInWelshDeveloper(String word) throws NullPointerException {

        for (HashMap.Entry<String, Word> entry : dictionary.entries())
            if (entry.getValue().getWelsh().equals(word)) {
                System.out.println(entry.getValue().toString());
                return entry.getValue().toString();
            }

        return null;
    }


    public void storeNewWordDeveloper(String english, String welsh, String type) {


        if (type.equals("nm")) {
            Word word = new NounM(english, welsh, type);
            dictionary.put(word.getEnglish(), word);
        } else if (type.equals("nf")) {
            Word word = new NounF(english, welsh, type);
            dictionary.put(word.getEnglish(), word);
        } else if (type.equals("v")) {
            Word word = new Verb(english, welsh, type);
            dictionary.put(word.getEnglish(), word);
        } else if (type.equals("other")) {
            Word word = new Other(english, welsh, type);
            dictionary.put(word.getEnglish(), word);
        }
    }
}


