package main;

public class NounM extends Word {



    public NounM(String welsh, String english, String wordType) {
        super(welsh, english, wordType);
    }
    @Override
    public String getType() {
        return "nm";
    }
    @Override
    public String getWelsh() {
        return super.getWelsh();
    }

    @Override
    public void setWelsh(String welsh) {
        super.setWelsh(welsh);
    }

    @Override
    public String getEnglish() {
        return super.getEnglish();
    }

    @Override
    public void setEnglish(String english) {
        super.setEnglish(english);
    }


    public NounM() {
        super();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
