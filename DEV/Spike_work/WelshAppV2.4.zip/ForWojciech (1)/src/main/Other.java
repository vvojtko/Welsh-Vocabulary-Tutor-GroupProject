package main;

public class Other extends Word {

    @Override
    public String getType() {
        return "other";
    }
    @Override
    public String getWelsh() {
        return super.getWelsh();
    }

    @Override
    public void setWelsh(String welsh) {
        super.setWelsh(welsh);
    }

    @Override
    public String getEnglish() {
        return super.getEnglish();
    }

    @Override
    public void setEnglish(String english) {
        super.setEnglish(english);
    }

    public Other(String englishMeaning, String welshMeaning, String wordType) {
        super(englishMeaning, welshMeaning, wordType);
    }

    public Other() {
        super();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
