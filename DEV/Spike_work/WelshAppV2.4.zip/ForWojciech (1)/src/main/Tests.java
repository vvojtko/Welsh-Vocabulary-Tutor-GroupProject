package main;

import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;


public class Tests {

    Dictionary dictionary = new Dictionary();


    String filePathToDictionary = "/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json";
    String filePathToPractiseList = "/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/practiselist.json";


    @Test
    public void loadingTest(){

        boolean thrown = false;
        try {
            dictionary.load("fakepath");
            Assertions.fail("Didn't throw even if the file path doesnt exists");
        }catch(FileNotFoundException e){
            thrown = true;
        }catch (
                IOException e) {
            e.printStackTrace();
        } catch (
                ParseException e) {
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }

        Assertions.assertTrue(thrown);
    }





    @Test
    public void searchingTest(){
        try {
            dictionary.load(filePathToDictionary);

        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch (
                IOException e) {
            e.printStackTrace();
        } catch (
                ParseException e) {
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }
        Assertions.assertEquals("Word{welsh='Unol Daleithiau ', english='United States ', wordType='other'}" ,dictionary.findWordInEnglishDeveloper("United States "));
        Assertions.assertEquals("Word{welsh='Unol Daleithiau ', english='United States ', wordType='other'}" ,dictionary.findWordInWelshDeveloper("Unol Daleithiau "));

    }

    @Test
    public void addAndSearchTest(){


        dictionary.storeNewWordDeveloper("Sample English Meaning","Sample Welsh Meaning","other");

        Assertions.assertEquals("Word{welsh='Sample Welsh Meaning', english='Sample English Meaning', wordType='other'}" ,dictionary.findWordInWelshDeveloper("Sample Welsh Meaning"));

    }


    @Test
    public void testAllWordTypes(){

        for(int i=0; i<4;i++) {
            switch (i) {
                case 0:
                    dictionary.storeNewWordDeveloper("Example English Verb", "Example Welsh Verb", "v");
                    Assertions.assertEquals("Word{welsh='Example Welsh Verb', english='Example English Verb', wordType='v'}", dictionary.findWordInEnglishDeveloper("Example English Verb"));
                    break;
                case 1:
                    dictionary.storeNewWordDeveloper("Example English Masculine Noun", "Example Welsh Masculine Noun", "nm");
                    Assertions.assertEquals("Word{welsh='Example Welsh Masculine Noun', english='Example English Masculine Noun', wordType='nm'}", dictionary.findWordInEnglishDeveloper("Example English Masculine Noun"));
                    break;
                case 2:
                    dictionary.storeNewWordDeveloper("Example English Feminine Noun", "Example Welsh Feminine Noun", "nf");
                    Assertions.assertEquals("Word{welsh='Example Welsh Feminine Noun', english='Example English Feminine Noun', wordType='nf'}", dictionary.findWordInEnglishDeveloper("Example English Feminine Noun"));
                    break;
                case 3:
                    dictionary.storeNewWordDeveloper("Example English Word", "Example Welsh Word", "other");
                    Assertions.assertEquals("Word{welsh='Example Welsh Word', english='Example English Word', wordType='other'}", dictionary.findWordInEnglishDeveloper("Example English Word"));
                    break;


            }
        }
    }







}
