package main;

public class Word implements Comparable<Word>{

    private String welsh;
    private String english;
    private String wordType;



    public String getType() {
        return wordType;
    }
    public String getWelsh() {
        return welsh;
    }

    public void setWelsh(String welsh) {
        this.welsh = welsh;
    }

    public String getEnglish() {
        return english;
    }

    public void setEnglish(String english) {
        this.english = english;
    }

    public Word(String englishMeaning, String welshMeaning, String wordType) {
        this.english = englishMeaning;
        this.welsh = welshMeaning;
        this.wordType = wordType;
    }

    public Word() {

    }


    /*
        @Override
        public String toString(){
            StringBuilder builder = new StringBuilder();

            builder.append("\nWelsh: ").append(welshMeaning);
            builder.append(", English: ").append(englishMeaning);
            builder.append(", Type: ");


            return builder.toString();
        }


     */
    public void display(){
        System.out.println( "English Meaning: " + english + "\nWelsh Meaning: " + welsh);
    }

    public int compareTo(Word o){
        return this.getEnglish().compareTo(o.getEnglish());
    }

    @Override
    public String toString() {
        return "Word{" +
                "welsh='" + welsh + '\'' +
                ", english='" + english + '\'' +
                ", wordType='" + getType() + '\'' +
                '}';
    }
}
