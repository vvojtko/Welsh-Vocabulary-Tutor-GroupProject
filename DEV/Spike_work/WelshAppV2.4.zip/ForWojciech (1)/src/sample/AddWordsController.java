package sample;

import com.google.common.collect.HashMultimap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;

public class AddWordsController extends HomeController implements Initializable{

    HashMultimap<String, Word> dictionaryMap;
    HashMultimap<String, Word> practiseMap = HashMultimap.create();
    String engToAdd;
    String welshToAdd;
   // @FXML TextField type;
    //ObservableList<Word> favWords  = FXCollections.observableArrayList();

    ObservableList<Word> data = FXCollections.observableArrayList();

    @FXML
    private TextField filterField;

    @FXML
    private TableView<Word> tableView;
    @FXML
    private TableColumn<Word, String> eng;
    @FXML
    private TableColumn<Word, String> welsh;
    @FXML
    private TableColumn<Word, String> wordType;

    @FXML public void engToWelsh(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(eng);
    }
    @FXML public void welshToEng(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(welsh);
    }

    @FXML TextField englishText;
    @FXML TextField welshText;
    @FXML TextField typeText;
    @FXML ChoiceBox<String> choiceBox;

    public final boolean containsDigit(String s) {
        boolean containsDigit = false;

        if (s != null && !s.isEmpty()) {
            for (char c : s.toCharArray()) {
                if (containsDigit = Character.isDigit(c)) {
                    break;
                }
            }
        }

        return containsDigit;
    }


    @FXML  public void addButton(ActionEvent event) throws IOException {

        String type = null;
        String eng = englishText.getText();

        String welsh = welshText.getText();

        type = choiceBox.getValue();
        if (containsDigit(eng) || containsDigit(welsh)) {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("Words cannot have digits inside!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 550, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        } else {
            if (type == null) {
                final Stage dialog = new Stage();
                VBox dialogVbox = new VBox(20);
                Text text = new Text(("Please choose a type of word from the choicebox!"));
                dialogVbox.getChildren().add(text);
                text.setTextAlignment(TextAlignment.CENTER);
                Scene dialogScene = new Scene(dialogVbox, 550, 50);
                dialog.setScene(dialogScene);
                dialog.show();
            } else {
                if ((eng.length() > 48)) {
                    final Stage dialog = new Stage();
                    VBox dialogVbox = new VBox(20);
                    Text text = new Text(("english word is too long!"));
                    dialogVbox.getChildren().add(text);
                    text.setTextAlignment(TextAlignment.CENTER);
                    Scene dialogScene = new Scene(dialogVbox, 550, 50);
                    dialog.setScene(dialogScene);
                    dialog.show();
                } else {
                    if ((welsh.length() > 28)) {
                        final Stage dialog = new Stage();
                        VBox dialogVbox = new VBox(20);
                        Text text = new Text(("welsh word is too long!"));
                        dialogVbox.getChildren().add(text);
                        text.setTextAlignment(TextAlignment.CENTER);
                        Scene dialogScene = new Scene(dialogVbox, 550, 50);
                        dialog.setScene(dialogScene);
                        dialog.show();
                    } else {
                        if (type.equals("noun feminine")) {
                            type = "nf";
                        } else if (type.equals("noun maskuline")) {
                            type = "nm";
                        } else if (type.equals("other")) {
                            type = "other";
                        } else if (type.equals("verb")) {
                            type = "v";
                        }
                        System.out.println(eng + " " + welsh + " " + type);
                        data.add(new Word(eng, welsh, type));
                        favWords.add(new Word(eng, welsh, type));
                        try {
                            File file = new File(filePathToDictionary);
                            FileWriter writer = new FileWriter(file);
                            String word = gson.toJson(data);
                            writer.write(word);
                            writer.close();

                            File file2 = new File(filePathToPractiseList);
                            FileWriter writer2 = new FileWriter(file2);
                            String word2 = gson.toJson(favWords);
                            writer2.write(word2);
                            writer2.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }
    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        try{
        dictionary.load(filePathToDictionary);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        FilteredList<Word> filteredList = new FilteredList<>(data, p -> true);
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if(word.getEnglish().toLowerCase().startsWith(lowerCaseFilter)) {
                    return true;
                    //        } else if (word.getWelsh().toLowerCase().contains(lowerCaseFilter)) {
                }else if(word.getWelsh().toLowerCase().startsWith(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });

        SortedList<Word> sortedList = new SortedList<>(filteredList);

        sortedList.comparatorProperty().bind(tableView.comparatorProperty());
        tableView.setItems(sortedList);
    }
    public void updateTable2() {
        Dictionary dictionary2 = new Dictionary();
        try{
        dictionary2.loadPrac(filePathToPractiseList);
        practiseMap = dictionary2.export();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (Map.Entry<String, Word> entry : practiseMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateTable();
        updateTable2();
        choiceBox.getItems().addAll("nm","verb","nf","other");
        eng.setCellValueFactory(new PropertyValueFactory<Word, String>("english"));
        welsh.setCellValueFactory(new PropertyValueFactory<Word, String>("welsh"));
        wordType.setCellValueFactory(new PropertyValueFactory<Word, String>("type"));
    }
}
