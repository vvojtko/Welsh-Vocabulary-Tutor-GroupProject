package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelpSceneController implements Initializable {
    private ImageView Img1;
    private ImageView Img2;
    public String name;

    @FXML
    ImageView imageView;
    @FXML
    HBox hbox;


    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    @FXML
    public void changeScreenButtonPushed(ActionEvent event) throws IOException {
        Image image = new Image(getClass().getResource("star.png").toExternalForm());
        imageView.setImage(image);

    }
    @FXML
    public void changeScreenButtonPushed2(ActionEvent event) throws IOException {
      Image image2 = new Image(getClass().getResource("remove.png").toExternalForm());
        imageView.setImage(image2);
    }
    @FXML
    public void changeScreenButtonPushed3(ActionEvent event) throws IOException {
        name = "star_black.png";

    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
