package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;

public class RevisionController extends HomeController implements Initializable{


    public ArrayList<Word> favouritesWords = new ArrayList<Word>();
    @FXML
    TextField textField;
    @FXML
    ImageView imageView;
    @FXML
    ImageView imageView2;
    @FXML
    ImageView imageView3;
    @FXML
    ImageView imageView4;

    Image image = new Image(getClass().getResource("matchthwords.png").toExternalForm());
    Image image2 = new Image(getClass().getResource("pick.png").toExternalForm());
    Image image3 = new Image(getClass().getResource("test.png").toExternalForm());
    Image image4 = new Image(getClass().getResource("flashcards.png").toExternalForm());
    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        try{
        dictionary.load(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        favouritesWords.addAll(data);

    }
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    @FXML
    public void changeScreenToMatch(ActionEvent event) throws IOException {
        if (favouritesWords.size() < 9) {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You don't have enough words to do this revision.\n" +
                    "Your practise list has to contain at least 8 words!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        } else {
            Main.showMatch();
        }
    }
    @FXML
    public void changeScreenToPick(ActionEvent event) throws IOException {
        if (favouritesWords.size() < 7) {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You don't have enough words to do this revision.\n" +
                    "Your practise list has to contain at least 6 words!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        } else {
            Main.showPick();
        }
    }

    @FXML
    public void changeScreenToTest(ActionEvent event) throws IOException {
        Main.showTest();
    }
    @FXML
    public void changeScreenToFlashcards(ActionEvent event) throws IOException {
        Main.showFlashcards();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    updateTable();
        imageView.setImage(image);

        imageView2.setImage(image2);

        imageView3.setImage(image3);

        imageView4.setImage(image4);

    }
}
