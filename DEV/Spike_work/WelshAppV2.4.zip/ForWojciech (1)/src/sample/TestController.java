package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;

public class TestController extends FlashcardsController implements Initializable {
    public ArrayList<Word> testWords = new ArrayList<Word>(10);
    int counter = 0;
    int words = 0;
    int score = 0;
    String eng = "";
    @FXML Button submit;
    @FXML
    TextField textField;

    @FXML
    TextArea showScore;

    @FXML TextField answer;
    @FXML public void next(ActionEvent event) throws IOException {
        submit.setDisable(false);
        counter++;
        textField.setStyle("-fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
        answer.setStyle("");
        textField.setText(testWords.get(counter).getEnglish());
    }
    @FXML public void submit(ActionEvent event) throws IOException {
        eng = answer.getText();
        if(eng.equals(testWords.get(counter).getWelsh())) {
            words++;
            score++;
            textField.setStyle("-fx-background-color: green; -fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
            answer.setStyle("-fx-background-color: green;");

        } else {
            words++;
            textField.setStyle("-fx-background-color: red; -fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
            answer.setStyle("-fx-background-color: red;");
        }
      //  textField.setText(testWords.get(counter).getEnglish());
        submit.setDisable(true);

        showScore.setText("Your score: " + score + "/" + words);
    }
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }
    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        try{
        dictionary.load(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //    ArrayList<Word> flashcardsWords = new ArrayList<Word>(10);
        //      System.out.println(randomSingleWordPicker().getEnglishMeaning());
        // System.out.println(flashcardsWords.toArray().toString());

        for (int i = 0; i < 10; i++) {
            testWords.add(i, randomSingleWordPicker());
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateTable();
        textField.setText(testWords.get(counter).getEnglish());
        showScore.setText("Your score: " + score + "/" + words);
    }
}
