package main;

public class NounM extends Word {

    private String gender;

    public NounM(String welsh, String english, String wordType) {
        super(welsh, english, wordType);
    }
    @Override
    public String getType() {
        return "nm";
    }
    @Override
    public String getWelsh() {
        return super.getWelsh();
    }

    @Override
    public void setWelsh(String welsh) {
        super.setWelsh(welsh);
    }

    @Override
    public String getEnglish() {
        return super.getEnglish();
    }

    @Override
    public void setEnglish(String english) {
        super.setEnglish(english);
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    /*
        public Noun(String welshMeaning, String englishMeaning,String gender) {
            setWelshMeaning(welshMeaning);
            setEnglishMeaning(englishMeaning);
            setGender(gender);;

        }


     */
    public NounM() {
        super();
    }


    @Override
    public void display(){
        System.out.println( "English Meaning:" + super.getEnglish() + "\nWelsh Meaning: " + super.getWelsh() +
                "\nGender: " + getGender());



    }



}
