package main;

public class Words extends Word {

    @Override
    public String getType() {
        return super.getType();
    }
    @Override
    public String getWelsh() {
        return super.getWelsh();
    }

    @Override
    public void setWelsh(String welsh) {
        super.setWelsh(welsh);
    }

    @Override
    public String getEnglish() {
        return super.getEnglish();
    }

    @Override
    public void setEnglish(String english) {
        super.setEnglish(english);
    }

    public Words(String englishMeaning, String welshMeaning, String wordType) {
        super(englishMeaning, welshMeaning, wordType);
    }

    public Words() {
        super();
    }

    @Override
    public void display(){
        System.out.println( "English Meaning: " + super.getEnglish() + "\nWelsh Meaning: " + super.getWelsh());



    }
}
