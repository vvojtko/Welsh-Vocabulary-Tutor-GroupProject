package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MatchTheWordsController implements Initializable {
    String match1;
    String match2;

    int counter = 0;
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    @FXML
    Button button1;
    @FXML
    Button button2;

    @FXML
    public void check(ActionEvent event) throws IOException {
        if (match1 == match2) {
            System.out.println("pasuja");
        } else {
            System.out.println("nie pasuja");
        }
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        button1.setOnAction(e -> {
            match1 = button1.getText();
            button1.setDisable(true);
            button1.setStyle("-fx-background-color: #06f27c");
            System.out.println(match1);
        });
        button2.setOnAction(e -> {
            match2 = button1.getText();
            button2.setDisable(true);
            button2.setStyle("-fx-background-color: #06f27c");
            System.out.println(match1);
        });

    }
}
