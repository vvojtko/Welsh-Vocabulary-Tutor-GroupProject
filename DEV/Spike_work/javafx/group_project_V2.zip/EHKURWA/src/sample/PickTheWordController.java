package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import main.Dictionary;
import main.Word;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;

public class PickTheWordController extends FlashcardsController implements Initializable {


   public int words;
   public int score;
    String answerr;
    ArrayList<Word> flashcardsWords = new ArrayList<Word>(6);
    @FXML
    TextArea showScore;

    @FXML
    Button answer1;
    @FXML
    Button answer2;
    @FXML
    Button answer3;
    @FXML
    Button answer4;
    @FXML
    Button answer5;
    @FXML
    Button answer6;
    @FXML
    Button answer7;
    @FXML
    Button answer8;


    @FXML
    HBox hbox;

    @FXML
    public void check14(ActionEvent event) throws IOException {
        if (answerr.equals(answer4.getText())) {
            score++;
            words++;
            answer4.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {
                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer5.getText())) {
                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer6.getText())) {
                words++;
                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            else if (answerr.equals(answer7.getText())) {
                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            words++;
            System.out.println("wrong");
        }

        buttonsDisable();
    }

    @FXML
    public void check12(ActionEvent event) throws IOException {
        if (answerr.equals(answer2.getText())) {
            answer2.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");
            score++;
            words++;
            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {

                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer5.getText())) {

                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            if (answerr.equals(answer7.getText())) {
                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            words++;
            System.out.println("wrong");
        }

        buttonsDisable();
    }

    @FXML
    public void check13() throws IOException {
        if (answerr.equals(answer3.getText())) {

            words++;
            score++;
            answer3.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            System.out.println("git");
        } else {
            if (answerr.equals(answer2.getText())) {

                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer3.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
//                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer5.getText())) {

                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            if (answerr.equals(answer7.getText())) {

                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            System.out.println("wrong");
            words++;
        }

        buttonsDisable();
    }

    @FXML
    public void check15() throws IOException {
        if (answerr.equals(answer5.getText())) {
            answer5.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            words++;
            score++;
            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {

                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            else if (answerr.equals(answer7.getText())) {

                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            words++;
            System.out.println("wrong");
        }
        buttonsDisable();
    }
    @FXML
    public void check16() throws IOException {
        if (answerr.equals(answer6.getText())) {

            words++;
            score++;
            answer6.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {
                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
           else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer5.getText())) {

                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");

              }

            else if (answerr.equals(answer7.getText())) {
                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

              }
            System.out.println("wrong");
            words++;
        }
        buttonsDisable();
    }
    public void buttonsDisable() throws IOException {

        answer1.setDisable(true);
        answer2.setDisable(true);
        answer3.setDisable(true);
        answer4.setDisable(true);
        answer5.setDisable(true);
        answer6.setDisable(true);
        answer7.setDisable(true);
    }

    public void buttonsEnable() throws IOException {

        answer1.setDisable(false);
        answer2.setDisable(false);
        answer3.setDisable(false);
        answer4.setDisable(false);
        answer5.setDisable(false);
        answer6.setDisable(false);
        answer7.setDisable(false);
    }
    @FXML
    public void check17() throws IOException {
        if (answerr.equals(answer7.getText())) {
            answer7.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");

            words++;
            score++;
            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {
                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");
  }
           else if (answerr.equals(answer4.getText())) {
                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");
            }
            else if (answerr.equals(answer5.getText())) {
                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            else if (answerr.equals(answer6.getText())) {
                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
            }
            words++;
            System.out.println("wrong");
        }
        buttonsDisable();
    }


    @FXML
    public void newSet(ActionEvent event) throws IOException {
        resetButtonStyles();
        buttonsEnable();
        daSomeShit();
        int x = (int) getRandomIntegerBetweenRange(0,5);
        answerr = flashcardsWords.get(x).getEnglish();
        answer1.setText(flashcardsWords.get(x).getWelsh());
        assignAnswers();
        showScore.setText("Your score: " + score + "/" + words);
    }

    private void resetButtonStyles() {
        answer1.setStyle("");
        answer2.setStyle("");
        answer3.setStyle("");
        answer4.setStyle("");
        answer5.setStyle("");
        answer6.setStyle("");
        answer7.setStyle("");

    }

    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    public static double getRandomIntegerBetweenRange(double min, double max){
        int x = (int) ((Math.random()*((max-min)+1))+min);
        return x;
    }
    public void daSomeShit() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        dictionary.load("/home/wojtko/Desktop/k/javafx/EHKURWA/src/main/dictionary.json");
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //    ArrayList<Word> flashcardsWords = new ArrayList<Word>(10);
        //      System.out.println(randomSingleWordPicker().getEnglishMeaning());
        // System.out.println(flashcardsWords.toArray().toString());

        for (int i = 0; i < 6; i++) {
            Word w = new Word();
            w = randomSingleWordPicker();
            if(!flashcardsWords.contains(w)) {
                flashcardsWords.add(i, randomSingleWordPicker());
            }else{
                while(!flashcardsWords.contains(w)) {
                    w = randomSingleWordPicker();
                }
            }
            }
    }
    public void assignAnswers(){
        answer6.setText(flashcardsWords.get(0).getEnglish());
        answer2.setText(flashcardsWords.get(1).getEnglish());
        answer3.setText(flashcardsWords.get(2).getEnglish());
        answer4.setText(flashcardsWords.get(3).getEnglish());
        answer5.setText(flashcardsWords.get(4).getEnglish());
        answer7.setText(flashcardsWords.get(5).getEnglish());
        }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        showScore.setText("Your score: " + score + "/" + words);
        showScore.setStyle("-fx-background-color:#80ced6");
        daSomeShit();
        int x = (int) getRandomIntegerBetweenRange(0,5);
        answerr = flashcardsWords.get(x).getEnglish();
        answer1.setText(flashcardsWords.get(x).getWelsh());
        assignAnswers();

    }
}