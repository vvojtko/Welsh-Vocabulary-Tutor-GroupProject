package sample;

        import javafx.beans.property.SimpleBooleanProperty;
        import javafx.beans.value.ObservableValue;
        import javafx.collections.FXCollections;
        import javafx.collections.ObservableList;
        import javafx.event.ActionEvent;
        import javafx.event.EventHandler;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.fxml.Initializable;
        import javafx.scene.Node;
        import javafx.scene.Scene;
        import javafx.scene.chart.XYChart;
        import javafx.scene.control.*;
        import javafx.scene.control.cell.PropertyValueFactory;
        import javafx.scene.input.KeyCode;
        import javafx.scene.input.KeyEvent;
        import javafx.stage.Stage;
        import javafx.util.Callback;
        import java.io.IOException;
        import javafx.scene.Parent;
        import java.net.URL;
        import java.util.Random;
        import java.util.ResourceBundle;

public class Controller implements Initializable {

  //  private AutoCompletionBinding<String> autoCompletionBinding;

    ObservableList<Words> data = FXCollections.observableArrayList();

    ObservableList<Words> data2 = FXCollections.observableArrayList();
    @FXML  private TableView tableView;
    @FXML private TableView tableView2;
    @FXML private TableColumn<Words, Integer> id2;
    @FXML private TableColumn<Words, String> eng;
    @FXML private TableColumn<Words, ButtonCell> button;
    @FXML private TableColumn<Words, String> welsh;
    @FXML private TableColumn<Words, String> type;
    @FXML private TableColumn<Words, String> favEng;
    @FXML private TableColumn<Words, ButtonCell> favButton;
    @FXML private TableColumn<Words, String> favWelsh;
    @FXML private TableColumn<Words, String> favType;



    private Button btnNew;

    static final String Day[] = {
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday"};
    static Random random = new Random();



    @FXML
    public void changeScreenButtonPushed(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("addScene.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }
    @FXML
    public void changeScreenButtonPushed3(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("helpScene.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    public void changeScreenButtonPushed2(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("addScene.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }
    @FXML
    public void changeScreenButtonPushed4(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("s2.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.show();
    }

    public void loadData(){

        data2.add(new Words("abbey", "abaty","nm",0));
        data2.add(new Words("about to", "ar fin","other",1));
        data2.add(new Words("action", "gweithred","nf",2));

        data2.add(new Words("action", "gweithred","nf",5));
        data2.add(new Words("action", "gweithred","nf",6));
        data2.add(new Words("actress", "actores","nf",3));
        data2.add(new Words("address", "cyfeiriad","nm",4));
        data2.add(new Words("administrative officer", "swyddog gweinyddol","nm",5));
       // data2.addAll(newWords, newWords2, newWords3);
        tableView2.setItems(data2);
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        tableView2.setEditable(true);

        Callback<TableColumn, TableCell> cellFactory =
                new Callback<TableColumn, TableCell>() {

                    @Override
                    public TableCell call(TableColumn p) {
                        return new EditingCell();
                    }
                };

        //loading data into tableView
        loadData();

      //====================================================
        eng.setCellValueFactory(new PropertyValueFactory<Words, String>("English"));
        welsh.setCellValueFactory(new PropertyValueFactory<Words, String>("Welsh"));
         type.setCellValueFactory(new PropertyValueFactory<Words, String>("Type"));
        favEng.setCellValueFactory(new PropertyValueFactory<Words, String>("English"));
        favWelsh.setCellValueFactory(new PropertyValueFactory<Words, String>("Welsh"));
        favType.setCellValueFactory(new PropertyValueFactory<Words, String>("Type"));

        //=========================================
        //Insert Button
        TableColumn col_action = new TableColumn<>("FAV");

        TableColumn col_action2 = new TableColumn<>("FAV");
        col_action.setSortable(false);

        col_action.setCellValueFactory(
                new Callback<TableColumn.CellDataFeatures<Words, Boolean>,
                        ObservableValue<Boolean>>() {

                    @Override
                    public ObservableValue<Boolean> call(TableColumn.CellDataFeatures<Words, Boolean> p) {
                        return new SimpleBooleanProperty(p.getValue() != null);
                    }
                });

        col_action.setCellFactory(
                new Callback<TableColumn<Words, Boolean>, TableCell<Words, Boolean>>() {

                    @Override
                    public TableCell<Words, Boolean> call(TableColumn<Words, Boolean> p) {
                        return new ButtonCell(tableView2);
                    }

                });
        col_action2.setCellValueFactory(
                new Callback<TableColumn.CellDataFeatures<Words, Boolean>,
                        ObservableValue<Boolean>>() {

                    @Override
                    public ObservableValue<Boolean> call(TableColumn.CellDataFeatures<Words, Boolean> p) {
                        return new SimpleBooleanProperty(p.getValue() != null);
                    }
                });

        col_action2.setCellFactory(
                new Callback<TableColumn<Words, Boolean>, TableCell<Words, Boolean>>() {

                    @Override
                    public TableCell<Words, Boolean> call(TableColumn<Words, Boolean> p) {
                        return new ButtonCell2(tableView);
                    }

                });
        tableView2.getColumns().add(col_action);
        tableView.getColumns().add(col_action2);

    }
    //Define the button cell
    private class ButtonCell extends TableCell<Words, Boolean> {        //<FavRecord, Boolean>
        final ToggleButton cellButton = new ToggleButton();


        ButtonCell(final TableView tblView) {
            cellButton.getStylesheets().add(this.getClass().getResource("toggle.css").toExternalForm());
            cellButton.setMinSize(35,35);
            cellButton.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent t) {
                    int selectedIndex = getTableRow().getIndex();

                    Words selectedRecord = (Words) tableView2.getItems().get(selectedIndex);

                    data.add(new Words(selectedRecord.getEnglish(), selectedRecord.getWelsh(), selectedRecord.getType(), selectedRecord.getId()));

                    tableView.setItems(data);

                }

            });
        }

        //;
        //Display button if the row is not empty

        @Override
        protected void updateItem(Boolean t, boolean empty) {
            super.updateItem(t, empty);
       //     if(!empty){
                setGraphic(cellButton);
         //   }
        }
    }

    private class ButtonCell2 extends TableCell<Words, Boolean> {        //<FavRecord, Boolean>
        final ToggleButton cellButton = new ToggleButton();


        ButtonCell2(final TableView tblView) {

            cellButton.getStylesheets().add(this.getClass().getResource("toggle_2.css").toExternalForm());
            cellButton.setMinSize(35, 35);
            cellButton.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent t) throws IndexOutOfBoundsException {
                    int selectedIndex = getTableRow().getIndex();

                    Words selectedRecord = (Words) tableView.getItems().get(selectedIndex);

                    data.remove(selectedRecord);

                    tableView.setItems(data);

                }

            });
        }

        //;
        //Display button if the row is not empty
        @Override
        protected void updateItem(Boolean t, boolean empty) {
            super.updateItem(t, empty);
              if(!empty){
                setGraphic(cellButton);
            }else{

              }
        }


    }
    class EditingCell extends TableCell<XYChart.Data, Number> {

        private TextField textField;

        public EditingCell() {}

        @Override
        public void startEdit() {

            super.startEdit();

            if (textField == null) {
                createTextField();
            }

            setGraphic(textField);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            textField.selectAll();
        }

        @Override
        public void cancelEdit() {
            super.cancelEdit();

            setText(String.valueOf(getItem()));
            setContentDisplay(ContentDisplay.TEXT_ONLY);
        }

        private void createTextField() {
            textField = new TextField(getString());
            textField.setMinWidth(this.getWidth() - this.getGraphicTextGap()*2);
            textField.setOnKeyPressed(new EventHandler<KeyEvent>() {

                @Override
                public void handle(KeyEvent t) {
                    if (t.getCode() == KeyCode.ENTER) {
                        commitEdit(Integer.parseInt(textField.getText()));
                    } else if (t.getCode() == KeyCode.ESCAPE) {
                        cancelEdit();
                    }
                }
            });
        }

        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
    }
}
