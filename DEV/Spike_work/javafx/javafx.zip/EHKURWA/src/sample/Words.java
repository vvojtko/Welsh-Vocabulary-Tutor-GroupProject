package sample;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;

public class Words {
  //  String english, welsh, type;
    SimpleStringProperty welsh;
    SimpleStringProperty type;
     SimpleStringProperty english;
     SimpleIntegerProperty id;
   // Button fav;

    public Words(String english, String welsh, String type, int id) {   //Button fav)

        this.english = new SimpleStringProperty(english);
        this.welsh = new SimpleStringProperty(welsh);
        this.type = new SimpleStringProperty(type);


        this.id = new SimpleIntegerProperty(id);
    }

    public String getWelsh() {
        return welsh.get();
    }

    public SimpleStringProperty welshProperty() {
        return welsh;
    }

    public void setWelsh(String welsh) {
        this.welsh.set(welsh);
    }

    public String getType() {
        return type.get();
    }

    public SimpleStringProperty typeProperty() {
        return type;
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public String getEnglish() {
        return english.get();
    }

    public SimpleStringProperty englishProperty() {
        return english;
    }

    public void setEnglish(String english) {
        this.english.set(english);
    }

    public int getId() {
        return id.get();
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }
}

