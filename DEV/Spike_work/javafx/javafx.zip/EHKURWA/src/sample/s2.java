package sample;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.io.IOException;
import javafx.scene.Parent;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

public class s2 implements Initializable{
    @FXML
    TextField textField;

    @FXML
    public void changeScreenButtonPushed(ActionEvent event) throws IOException {
        textField.setText("weed");

    }
    @FXML
    public void changeScreenButtonPushed2(ActionEvent event) throws IOException {
        textField.setText("heroine");

    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        textField.setText("Hello");
    }
}
