This folder contains the maintenance tools for the Welsh Learners program, as well as an original copy of dictionary.json.

DO NOT MOVE/EDIT ANY OF THESE FILES. Doing so can result in the scripts not working at all, or working incorrectly. In the worst case this can result in an incorrect file being overwritten.