/**
 * @(#) AddWordsController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package javafx;

/**
 * AddWordsController - A controller class that allows user to do add a new word
 * into a dictionary and practise list. It displays table with dictionary table too.
 * @author wos2
 */

import com.google.common.collect.HashMultimap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class AddWordsController extends HomeController implements Initializable {

    // //////////////// //
    // Class variables. //
    // //////////////// //

    //implementation of ADTs for running, displaying and retrieving values
    public HashMultimap<String, Word> dictionaryMap; //Dictionary class objects to operate with json files and reads it into objects
    //Guava Hashmultimap objects to store words with multiple meanings
    public HashMultimap<String, Word> practiseMap = HashMultimap.create();
    //observable list objects for table views
    public ObservableList<Word> data = FXCollections.observableArrayList();
    //hashset for receiving collections from hashmultimap keys
    public Set<Word> wordHashSet = new HashSet<>();

    @FXML
    private TextField filterField;  //searchbox filter field


    //table creating fx ids
    @FXML
    private TableView<Word> tableView;
    @FXML
    private TableColumn<Word, String> eng;
    @FXML
    private TableColumn<Word, String> welsh;
    @FXML
    private TableColumn<Word, String> wordType;


    // //////// //
    // Methods. //
    // //////// //


    //method to change order of displaying words in table
    @FXML
    public void engToWelsh(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(eng);
    }

    //method to change order of displaying words in table
    @FXML
    public void welshToEng(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(welsh);
    }


    //text fields and choicebox fx ids for getting user input of new word
    @FXML
    TextField englishText;
    @FXML
    TextField welshText;
    @FXML
    TextField typeText;
    @FXML
    ChoiceBox<String> choiceBox;


    //boolean method that checks if strings contains digit inside
    public final boolean containsDigit(String s) {
        boolean containsDigit = false;

        if (s != null && !s.isEmpty()) {
            for (char c : s.toCharArray()) {
                if (containsDigit = Character.isDigit(c)) {
                    break;
                }
            }
        }

        return containsDigit;
    }

    //method that is responsible for adding the word into dictionary and practise list
    //checks if input is desired and if not it pops up error messages for user
    //finally overwrites file with updated data by new word

    @FXML
    public void addButton(ActionEvent event) throws IOException {
        boolean contains = false; //boolean value for checking if hashset contains word objects that contains same welsh and english meaning as new word
        String type = null;     //sets type for null in purpose of error messages

        //gets user input and creates object from that
        String eng = englishText.getText();
        String welsh = welshText.getText();
        type = choiceBox.getValue();

        Word w = new Word(eng, welsh, type);
        if (containsDigit(eng) || containsDigit(welsh)) {       //checks if english or welsh words provided contains digit inside and returns message if they do
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("Words cannot have digits inside!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 550, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        } else {
            if (type == null) { //checks if user provided type - if not returns error message explaining mistake
                final Stage dialog = new Stage();
                VBox dialogVbox = new VBox(20);
                Text text = new Text(("Please choose a type of word from the choicebox!"));
                dialogVbox.getChildren().add(text);
                text.setTextAlignment(TextAlignment.CENTER);
                Scene dialogScene = new Scene(dialogVbox, 550, 50);
                dialog.setScene(dialogScene);
                dialog.show();
            } else {
                if ((eng.length() > 48)) {   //checks for length english word and returns error message when it's too long explaining mistake
                    final Stage dialog = new Stage();
                    VBox dialogVbox = new VBox(20);
                    Text text = new Text(("english word is too long!"));
                    dialogVbox.getChildren().add(text);
                    text.setTextAlignment(TextAlignment.CENTER);
                    Scene dialogScene = new Scene(dialogVbox, 550, 50);
                    dialog.setScene(dialogScene);
                    dialog.show();
                } else {
                    if ((welsh.length() > 28)) { //checks for length welsh word and returns error message when it's too long explaining mistake
                        final Stage dialog = new Stage();
                        VBox dialogVbox = new VBox(20);
                        Text text = new Text(("welsh word is too long!"));
                        dialogVbox.getChildren().add(text);
                        text.setTextAlignment(TextAlignment.CENTER);
                        Scene dialogScene = new Scene(dialogVbox, 550, 50);
                        dialog.setScene(dialogScene);
                        dialog.show();
                    } else {    //checks for type and reassign it to format of type in json files
                        if (type.equals("noun feminine")) {
                            type = "nf";
                        } else if (type.equals("noun maskuline")) {
                            type = "nm";
                        } else if (type.equals("other")) {
                            type = "other";
                        } else if (type.equals("verb")) {
                            type = "v";
                        }
                        //adds the word to data structures if met all the conditions
                        data.add(new Word(eng, welsh, type));
                        favWords.add(new Word(eng, welsh, type));

                        //overwrites the file adding new added word
                        try {
                            File file = new File(filePathToDictionary);
                            FileWriter writer = new FileWriter(file);
                            String word = gson.toJson(data);
                            writer.write(word);
                            writer.close();

                            File file2 = new File(filePathToPractiseList);
                            FileWriter writer2 = new FileWriter(file2);
                            String word2 = gson.toJson(favWords);
                            writer2.write(word2);
                            writer2.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
    //method to change scene to help scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    //method to change scene to home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    //method to change scene to revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }



    //method that uploads json file and loads it into tables
    //casting through different adt (same as in home controller) and
    //bind search box with table and sets the items of dictionary.json in table view

    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        try{
        dictionary.load(filePathToDictionary);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        dictionaryMap = dictionary.export(); //dictionary method for returns hashmultimap
        //for loop that goes through entries and add each of entry into observable list
        //and checks for right type of word so based on that creates proper Word object
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //casting observable list into filtered list
        FilteredList<Word> filteredList = new FilteredList<>(data, p -> true);

        //binds search box with filtered list and sets predicates based on main choosen language
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if(word.getEnglish().toLowerCase().startsWith(lowerCaseFilter)) {
                    return true;
                }else if(word.getWelsh().toLowerCase().startsWith(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });
        //casts filtered lists to sorted list
        SortedList<Word> sortedList = new SortedList<>(filteredList);

        //binds sorted list with table view to display values
        sortedList.comparatorProperty().bind(tableView.comparatorProperty());

        //sets items of sorted lists in table view
        tableView.setItems(sortedList);
    }

    //method that opens practise lists json file and loads it into dictionary objects
    //and then overwrites the file with updated data

    public void updateTable2() {
        Dictionary dictionary2 = new Dictionary();
        try{
        dictionary2.loadPrac(filePathToPractiseList);
        practiseMap = dictionary2.export();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //for loop that goes through entries and add each of entry into observable list
        //and checks for right type of word so based on that creates proper Word object
        for (Map.Entry<String, Word> entry : practiseMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateTable();
        updateTable2();

        //below is setting up the table view with parameters
        choiceBox.getItems().addAll("nm","verb","nf","other");
        eng.setCellValueFactory(new PropertyValueFactory<Word, String>("english"));
        welsh.setCellValueFactory(new PropertyValueFactory<Word, String>("welsh"));
        wordType.setCellValueFactory(new PropertyValueFactory<Word, String>("type"));
    }
}
