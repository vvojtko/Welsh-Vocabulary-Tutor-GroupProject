/**
 * @(#) FlashcardsController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package javafx;
/**
 * FlashcardsController - A controller class that allows user to do revision
 * of flashcards type
 * @author ars21
 * @author jas117
 * @author wos2
 */
import com.google.common.collect.HashMultimap;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class FlashcardsController extends HomeController implements Initializable {

    // //////////////// //
    // Class variables. //
    // //////////////// //

    @FXML
    TextField textField;
    @FXML
    Button next;

    @FXML
    Button prev;

    public Set<Word> wordHashSet = new HashSet<>();
    int changeSide = 1;
    public ArrayList<Word> flashcardsWords = new ArrayList<Word>();
    public HashMultimap<String, Word> flashcardsWordsMap = HashMultimap.create();

    public int counter = 0;
    int language = 0;



    // //////// //
    // Methods. //
    // //////// //
    @FXML
    public void nextFlashcard(ActionEvent event) throws IOException {
        if (language == 0) {
            if (counter < data.size()) {
                counter++;
                textField.setText(flashcardsWords.get(counter).getEnglish());
            }
            if (counter == data.size()) {
                Main.showRevision();
            }
            if (counter == data.size() - 1) {
                next.setText("Menu");
                counter++;
            }
        } else if (language == 1) {
            counter++;
            if (counter < data.size()) {
                textField.setText(flashcardsWords.get(counter).getWelsh());
                if(counter == data.size()-1){
                    next.setText("Menu");
                }

            }
            if (counter == data.size()) {
                next.setText("Menu");
                counter++;
            }
            if (counter == data.size()+1) {
                Main.showRevision();
            }



        }
    }

    @FXML
    void newSet(ActionEvent event) throws IOException {
        updateTable();
        counter = 0;
    }

    @FXML
    public void previousFlashcard(ActionEvent event) {
        next.setText("Next");
        if (language == 0) {
            if (counter == data.size()) {
                counter = counter - 2;
                textField.setText(flashcardsWords.get(counter).getEnglish());
            } else if (counter > 0) {
                next.setText("Next");
                counter--;
                textField.setText(flashcardsWords.get(counter).getEnglish());
            } else {
                final Stage dialog = new Stage();
                VBox dialogVbox = new VBox(20);
                Text text = new Text(("No previous flashcards, go to next flashcards"));
                dialogVbox.getChildren().add(text);
                text.setTextAlignment(TextAlignment.CENTER);
                Scene dialogScene = new Scene(dialogVbox, 450, 50);
                dialog.setScene(dialogScene);
                dialog.show();
            }
            if (counter == data.size()) {
                counter = counter - 2;
            }
        } else if (language == 1) {
            if (counter == data.size()) {
                counter = counter - 2;
                textField.setText(flashcardsWords.get(counter).getWelsh());
            } else if (counter > 0) {
                next.setText("Next");
                counter--;
                textField.setText(flashcardsWords.get(counter).getWelsh());
            } else {
                final Stage dialog = new Stage();
                VBox dialogVbox = new VBox(20);
                Text text = new Text(("No previous flashcards, go to next flashcards"));
                dialogVbox.getChildren().add(text);
                text.setTextAlignment(TextAlignment.CENTER);
                Scene dialogScene = new Scene(dialogVbox, 450, 50);
                dialog.setScene(dialogScene);
                dialog.show();
            }
            if (counter == data.size()) {
                counter = counter - 2;
            }


        }
    }


    @FXML
    public void translate(ActionEvent event) throws IOException {
        if (language == 0) {

            if(changeSide==1) {
                if (counter == data.size()) {
                    counter--;
                    textField.setText(flashcardsWords.get(counter).getWelsh());
                    counter++;
                }
                else {
                    textField.setText(flashcardsWords.get(counter).getWelsh());
                }
                changeSide = 2;
            }
            else{
                if (counter == data.size()) {
                    counter--;
                    textField.setText(flashcardsWords.get(counter).getEnglish());
                    counter++;
                }
                else {
                    textField.setText(flashcardsWords.get(counter).getEnglish());
                }
                changeSide = 1;
            }


        } if(changeSide==1) {
            if (counter == data.size()) {
                counter--;
                textField.setText(flashcardsWords.get(counter).getEnglish());
                counter++;
            }
            else {
                textField.setText(flashcardsWords.get(counter).getEnglish());
            }
            changeSide = 2;
        }
        else{
            if (counter == data.size()) {
                counter--;
                textField.setText(flashcardsWords.get(counter).getWelsh());
                counter++;
            }
            else {
                textField.setText(flashcardsWords.get(counter).getWelsh());
            }
            changeSide = 1;
        }
    }




    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your
        try {
            dictionary.load(filePathToPractiseList);
            System.out.println("loaded");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
                System.out.println("added");
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
                System.out.println("added");
            }
        }
        Random random = new Random();
        //      for(int i = 0; i < data.size()-1; i++) {
        int loopInt = 0;


        while (!(flashcardsWords.size() == data.size())) {
            boolean contains = false;
            Word w = data.get(random.nextInt(data.size()));
            if (!flashcardsWordsMap.containsKey(w.getEnglish())) {
                flashcardsWordsMap.put(w.getEnglish(), w);
                flashcardsWords.add(loopInt, w);
                loopInt++;
            }
            if (flashcardsWordsMap.containsKey(w.getEnglish())) {
                wordHashSet = flashcardsWordsMap.get(w.getEnglish());
                for (Word word : wordHashSet) {
                    if (!word.getWelsh().equals(w.getWelsh())) {
                        flashcardsWords.add(loopInt, w);
                        flashcardsWordsMap.put(w.getEnglish(), w);
                        loopInt++;
                    }
                }
            }

        /*
        while (!(flashcardsWords.size() == data.size())) {
            boolean contains = false;
            Word w = data.get(random.nextInt(data.size()));
            if (!flashcardsWordsMap.containsKey(w.getEnglish())) {
                flashcardsWordsMap.put(w.getEnglish(), w);
                flashcardsWords.add(loopInt, w);
                loopInt++;
            } else if (flashcardsWordsMap.containsKey(w.getEnglish())) {
                wordHashSet.addAll(flashcardsWordsMap.get(w.getEnglish()));
                if (wordHashSet.size() > 0) {
                    for (Word word : wordHashSet) {
                        if (word.getWelsh().equals(w.getWelsh())) {
                            contains = true;
                        }
                    }
                    if (!contains) {
                        flashcardsWordsMap.put(w.getEnglish(), w);
                        flashcardsWords.add(loopInt, w);
                        loopInt++;
                    }
                }

            }
        }
        */
        }
    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateTable();
        if (language == 0) {
            System.out.println("counter : " + counter + "word: " + flashcardsWords.get(counter).getEnglish());
            textField.setText(String.valueOf(flashcardsWords.get(counter).getEnglish()));
        } else if (language == 1) {
            System.out.println("counter : " + counter + "word: " + flashcardsWords.get(counter).getWelsh());
            textField.setText(String.valueOf(flashcardsWords.get(counter).getWelsh()));

        }
    }

}