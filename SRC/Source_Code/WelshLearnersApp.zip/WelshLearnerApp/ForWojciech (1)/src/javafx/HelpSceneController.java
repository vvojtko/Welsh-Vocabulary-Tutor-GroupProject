/**
 * @(#) HelpController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package javafx;
/**
 * HelpController - A controller class that displays helps images
 * that will help user to understand the way program works
 * @author wos2
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelpSceneController implements Initializable {


    @FXML
    ImageView imageView;

    Image image = new Image(getClass().getResource("Capture2.png").toExternalForm());
    Image image3 = new Image(getClass().getResource("addword.png").toExternalForm());
    Image image2 = new Image(getClass().getResource("revision.png").toExternalForm());

    // //////// //
    // Methods. //
    // //////// //

    //method to change scene to help scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }
    //method to change scene to home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }
    //method to change scene to revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }
    //method to change scene to add word scene
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }
    //method to change help image for home scene
    @FXML
    public void changeScreenButtonPushed(ActionEvent event) throws IOException {
        imageView.setImage(image);

    }
    //method to change help image for revision
    @FXML
    public void changeScreenButtonPushed2(ActionEvent event) throws IOException {
        imageView.setImage(image2);
    }
    //method to change help image for add words scene
    @FXML
    public void changeScreenButtonPushed3(ActionEvent event) throws IOException {
        imageView.setImage(image3);
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        imageView.setImage(image);
    }
}
