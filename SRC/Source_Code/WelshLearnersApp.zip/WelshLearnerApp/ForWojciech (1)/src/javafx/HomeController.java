/**
 * @(#) HomeController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package javafx;

/**
 * HomeController - A controller class that displays all words in tables
 * allows user to go to different scenes or display
 *
 * @author wos2
 */


import com.google.gson.*;
import com.google.common.collect.HashMultimap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;

import javafx.util.Callback;
import main.*;
import main.Dictionary;
import org.json.simple.parser.ParseException;

import java.net.URL;
import java.util.*;

public class HomeController implements Initializable {

    //String for setting up the paths of json files
    String filePathToDictionary = "/home/wojtko/Downloads/ForWojciech (1)/src/main/dictionary.json";
    String filePathToPractiseList = "/home/wojtko/Downloads/ForWojciech (1)/src/main/practiselist.json";


    boolean showPractiseList = false;   //variable to make practise list visible or not
    private Dictionary dictionary;      //Dictionary class objects to operate with json files and reads it into objects
    private Dictionary dictionary2;

    public Gson gson = new Gson(); //gson object to overwrite the practise list

    public boolean language = false;    //boolean variable to change main language for search box

    //Guava Hashmultimaps objects to store words with multiple meanings
    public HashMultimap<String, Word> dictionaryMap = HashMultimap.create();
    public HashMultimap<String, Word> practiseMap = HashMultimap.create();

    //2 observable list objects for table views
    public ObservableList<Word> data = FXCollections.observableArrayList();
    public ObservableList<Word> favWords = FXCollections.observableArrayList();

    //first table creating fx ids

    @FXML
    public TableColumn<Word, Void> colBtn;
    @FXML
    private TextField filterField;
    @FXML
    private TableView<Word> tableView;
    @FXML
    private TableColumn<Word, String> eng;
    @FXML
    private TableColumn<Word, String> welsh;
    @FXML
    private TableColumn<Word, String> wordType;

    //second table creating fx ids
    @FXML
    public TableColumn<Word, Void> colBtn2;
    @FXML
    private TextField filterField2;
    @FXML
    private TableView<Word> tableView2;
    @FXML
    private TableColumn<Word, String> eng2;
    @FXML
    private TableColumn<Word, String> welsh2;
    @FXML
    private TableColumn<Word, String> wordType2;


    // //////// //
    // Methods. //
    // //////// //

    //method to change order of displaying words in table
    @FXML
    public void engToWelsh(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(eng);
        language = true;
    }

    //method to change order of displaying words in table
    @FXML
    public void welshToEng(ActionEvent event) throws IOException {
        tableView.getSortOrder().setAll(welsh);

        language = false;
    }


    //method to change scene to home scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }


    //method to make visible or invisible the practise list
    @FXML
    public void setTableViewInVisible(ActionEvent event) throws IOException {

        if (showPractiseList == true) {
            tableView2.setVisible(false);
            showPractiseList = false;
        } else {
            tableView2.setVisible(true);
            showPractiseList = true;
            tableView2.getSortOrder().setAll(welsh);
        }
    }


    //method to change scene to home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }


    //method to change scene for revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    //method to change scene for Add Word scene
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    /**method that places buttons in a column
     * gets a value of selected row and removes the value to practise list table
     *with inner class of overridden TableCell class that allows to create a button in each cell
     */
    void removingButtons() throws NullPointerException {


        Callback<TableColumn<Word, Void>, TableCell<Word, Void>> cellFactory
                = new Callback<TableColumn<Word, Void>, TableCell<Word, Void>>() {
            @Override
            public TableCell<Word, Void> call(TableColumn<Word, Void> param) {
                final TableCell<Word, Void> cell = new TableCell<Word, Void>() {
                    final Button btn = new Button("-");

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {
                            btn.setOnAction(event -> {  //set on action that removes variable from practise list
                                Word word = getTableView().getItems().get(getIndex());
                                //   if (!favWords.contains(word)) {
                                favWords.remove(word);
                                practiseMap.removeAll(word.getEnglish());
                                try {   //overwriting the practise list .json file with updated data
                                    File file = new File(filePathToPractiseList);
                                    FileWriter writer = new FileWriter(file);
                                    String wordd = gson.toJson(favWords);
                                    writer.write(wordd);
                                    writer.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                            });
                            setGraphic(btn);
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };

        //updates table with all words minus the removed word
        try {
            dictionary2.loadPrac(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //exports updated practise list and sets one of the column as column with removing buttons
        practiseMap = dictionary2.export();
        colBtn2.setCellFactory(cellFactory);
    }

    /**method that places buttons in a column
     * gets a value of selected row and passes the value to practise list table
     with inner class of overridden TableCell class that allows to create a button in each cell
     */
    void addButtons() throws NullPointerException {

        Callback<TableColumn<Word, Void>, TableCell<Word, Void>> cellFactory
                = new Callback<TableColumn<Word, Void>, TableCell<Word, Void>>() {
            @Override
            public TableCell<Word, Void> call(TableColumn<Word, Void> param) {
                final TableCell<Word, Void> cell = new TableCell<Word, Void>() {
                    final Button btn = new Button("+");

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                            setText(null);
                        } else {
                            btn.setOnAction(event -> {  //sets button on action to pass value of selected row to practise list
                                Word word = getTableView().getItems().get(getIndex());
                                if (!practiseMap.containsKey(word.getEnglish())) {  //checks if practise list already contains the selected word
                                    favWords.add(new Word(word.getEnglish(), word.getWelsh(), word.getType()));
                                    practiseMap.put(word.getEnglish(), new Word(word.getEnglish(), word.getEnglish(), word.getType()));
                                    //overwriting the practise list .json file with updated data
                                    try {
                                        File file = new File(filePathToPractiseList);
                                        FileWriter writer = new FileWriter(file);
                                        String wordd = gson.toJson(favWords);
                                        writer.write(wordd);
                                        writer.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }

                                } else {    //anonymous println saying that adding failed
                                    System.out.println("fail");
                                }


                            });
                            setGraphic(btn);
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };
        colBtn.setCellFactory(cellFactory);
    }

    /**major method that is responsible for loading .json files into tables
     * and binds searchbox with finally sorted lists
     */

    public void updateTable() {
        dictionary = new Dictionary();
        try {
            dictionary.load(filePathToDictionary);  //dictionary method for loading .json file
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export(); //dictionary method for returns hashmultimap
        /**for loop that goes through entries and add each of entry into observable list
         * and checks for right type of word so based on that creates proper Word object
         */
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {

            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == "other") {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else if (wt == "nf") {
                data.add(new NounF(word.getEnglish(), word.getWelsh(), "nf"));
            } else if (wt.equals("nm")) {
                data.add(new NounM(word.getEnglish(), word.getWelsh(), "nm"));
            } else {
                data.add(new Verb("to " + word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //casting observable list into filtered list
        FilteredList<Word> filteredList = new FilteredList<>(data, p -> true);
        //binds search box with filtered list and sets predicates based on main choosen language
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                if (!language) {
                    if (word.getEnglish().toLowerCase().startsWith(lowerCaseFilter)) {
                        return true;
                    }
                } else if (language) {
                    if (word.getWelsh().toLowerCase().startsWith(lowerCaseFilter)) {
                        return true;
                    }
                }
                return false;

            });
        });

        //casts filtered lists to sorted list
        SortedList<Word> sortedList = new SortedList<>(filteredList);

        //binds sorted list with table view to display values
        sortedList.comparatorProperty().bind(tableView.comparatorProperty());
        //sets items of sorted lists in table view
        tableView.setItems(sortedList);
    }

    /**
     *major method that is responsible for loading .json files into tables
     * and binds searchbox with finally sorted lists
     */
    public void updateTable2() {
        dictionary2 = new Dictionary();
        try {
            dictionary2.loadPrac(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        practiseMap = dictionary2.export();
        //for loop that goes through entries and add each of entry into observable list
        //and checks for right type of word so based on that creates proper Word object
        for (Map.Entry<String, Word> entry : practiseMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                favWords.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        //casting observable list into filtered list
        FilteredList<Word> filteredList = new FilteredList<>(favWords, p -> true);

        //binds search box with filtered list and sets predicates based on main choosen language
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (word.getEnglish().toLowerCase().startsWith(lowerCaseFilter)) {
                    return true;
                    //        } else if (word.getWelsh().toLowerCase().contains(lowerCaseFilter)) {
                } else if (word.getWelsh().toLowerCase().startsWith(lowerCaseFilter)) {
                    return true;
                }
                return false;
            });
        });
        //casts filtered lists to sorted list
        SortedList<Word> sortedList = new SortedList<>(filteredList);

        //binds sorted list with table view to display values
        sortedList.comparatorProperty().bind(tableView2.comparatorProperty());
        //sets items of sorted lists in table view
        tableView2.setItems(sortedList);

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateTable();
        updateTable2();
        addButtons();
        removingButtons();

        /**
         * below is setting up the table view with parameters
         * and table view no. 2 with parameters
         * such as english, welsh, type and buttons
         */
        colBtn.setCellValueFactory(new PropertyValueFactory<Word, Void>("addButton"));
        welsh.setCellValueFactory(new PropertyValueFactory<Word, String>("english"));
        eng.setCellValueFactory(new PropertyValueFactory<Word, String>("welsh"));
        wordType.setCellValueFactory(new PropertyValueFactory<Word, String>("type"));
        colBtn2.setCellValueFactory(new PropertyValueFactory<Word, Void>("removingButton"));
        welsh2.setCellValueFactory(new PropertyValueFactory<Word, String>("welsh"));
        eng2.setCellValueFactory(new PropertyValueFactory<Word, String>("english"));
        wordType2.setCellValueFactory(new PropertyValueFactory<Word, String>("type"));
        tableView2.setVisible(showPractiseList);    //sets practise list invisible
        tableView.getSortOrder().setAll(welsh); //sets order of displaying dictionary list
    }
}


