/**
 * @(#) Main.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */
package javafx;
/**
 *  Main - A java class runs the application and
 *  contains methods to change scenes.
 * @author wos2
 */
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    private static Stage primaryStage;  //creates stage
    private static GridPane mainLayout; //creates grid pane



    // //////// //
    // Methods. //
    // //////// //

    //starts app and shows home scene as default
    @Override
    public void start(Stage primaryStage) throws Exception {
        Main.primaryStage = primaryStage;
        Main.primaryStage.setTitle("Welsh Learning App");
        showHome();

    }
    //method to change scene to home scene
    public static void showHome() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("HomeScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    //method to change scene to help scene
    public static void showHelp() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("HelpScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }
    //method to change scene to add words scene
    public static void showAdd() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("AddWordsScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    //method to change scene to revision scene
    public static void showRevision() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("RevisionScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void showMatch() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("MatchTheWords.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void showTest() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("TestScene.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void showPick() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("PickTheWordController.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void showFlashcards() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("flashcards.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);

        scene.getStylesheets().add(Main.class.getResource("main.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);

    }

}
