/**
 * @(#) MatchTheWordsController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package javafx;
/**
 * MatchTheWordsController - A controller class that allows user to do revision
 * of match the words controller.
 * @author wos2
 */
import com.google.common.collect.HashMultimap;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class MatchTheWordsController extends HomeController implements Initializable {


    // //////////////// //
    // Class variables. //
    // //////////////// //

    //Guava Hashmultimaps objects to store words with multiple meanings
    public HashMultimap<String, Word> dictionaryMap = HashMultimap.create();

    int checker = 0;    //int variable for checking if every word has been matched
    int score = 0;      //int variable keeping track of score
    int words = 0;       //int variable keeping track number of questions
    public Stack<String> answers = new Stack<String>(); //stack for keeping track of button clicks order to get user matches
    public List<Integer> numbers = new ArrayList<>();       //list for making button text always random
    public ArrayList<Word> matchWordsList = new ArrayList<Word>(4);    //arraylist keeps 4 words objects for matching
    public HashMap<String, Word> matchWordsMap = new HashMap<>();      //hashmap that checks avoids repeated words
    public HashMap<String, Word> hashMapEnglish = new HashMap<>(); //hashmap that checks avoids repeated words
    public HashMap<String, Word> hashMapWelsh = new HashMap<>(); //hashmap that checks avoids repeated words
    public String match1, match2, match3, match4, match5, match6, match7, match8 = ""; //strings for comparing user answers



    // //////// //
    // Methods. //
    // //////// //

    //method to change scene to help scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    //method to change scene to home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    //method to change scene to revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    //method to change scene to add word scene
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }


    //sets up buttons fx ids for dealing with styles, color, getText
    @FXML
    Button button1;
    @FXML
    Button button2;
    @FXML
    Button button3;
    @FXML
    Button button4;
    @FXML
    Button button5;
    @FXML
    Button button6;
    @FXML
    Button button7;
    @FXML
    Button button8;

    //@FXML Button submit;

    //text for displaying current state of user's score
    @FXML
    Text showScore;

    /**
     * submit method that checks is all buttons has been matched
     * checks for right answer by calling correctChecker(), updates table (data) and assigns button new answers
     * in case of not each word has been clicked (matched) it pops up error message explaining user's mistake
     */
    public void submit() {
        if (checker == 8) {
            checker = 0;    //reassigns checker value for the next set of words
            correctChecker();
            updateTable();
            assignButtons();
            showScore.setText("Your score: " + score + "/" + words);
        } else {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("Match all the words to submit!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        }
    }

    /**
     * this function is just loading data into list and pick 4 random words
     * then it puts it into flashcardsWords arraylist on which buttons and meaning works
     */
    public void updateTable() {

        Dictionary dictionary = new Dictionary();   //dictionary method for loading .json file
        try {
            dictionary.load(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();    //dictionary method for returns hashmultimap

        /**for loop that goes through entries and add each of entry into observable list
         * and checks for right type of word so based on that creates proper Word object
         */

        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }

        Random random = new Random();
        int loopInt = 0;    //variable for indexing the added word of flashcards words
        /**
         * while loop that runs until flashcards size reach 4
         * it adds words from data array list to matchWordsList and also puts the word in hashmap
         * based on hashmap it adds new words, making sure the words don't repeat
         * incrementing loopInt while word is being added for keeping indexing the objects
         */
        while (!(matchWordsList.size() == 4)) {
            Word w = data.get(random.nextInt(data.size())); //gets random word from data list
            if (!matchWordsMap.containsKey(w.getEnglish())) {
                matchWordsMap.put(w.getEnglish(), w);
                matchWordsList.add(loopInt, w);
                loopInt++;
            }
        }

    }


    /**
     * assigns english and welsh meaning to buttons
     * and sets buttons styles for "" (default)
     * uses random generator to always get randomized words
     */
    public void assignButtons() {
        Random randomGenerator = new Random();

        //int variables for indexing
        int b1 = 0;
        int b2 = 1;
        int b3 = 2;
        int b4 = 3;
        numbers.add(b1);
        numbers.add(b2);
        numbers.add(b3);
        numbers.add(b4);

        int randomInt0 = randomGenerator.nextInt(3);
        button1.setText(matchWordsList.get(numbers.remove(randomInt0)).getEnglish());
        button1.setStyle("");

        randomInt0 = randomGenerator.nextInt(2);
        button2.setText(matchWordsList.get(numbers.remove(randomInt0)).getEnglish());
        button2.setStyle("");

        randomInt0 = randomGenerator.nextInt(1);
        button3.setText(matchWordsList.get(numbers.remove(randomInt0)).getEnglish());
        button3.setStyle("");

        randomInt0 = randomGenerator.nextInt(1);
        button4.setText(matchWordsList.get(numbers.remove(randomInt0)).getEnglish());
        button4.setStyle("");

        /**
         * once buttons are assigned with required text (english words)
         * it does the same for english and randomizing the order of displaying welsh words
         */
        numbers.add(b1);
        numbers.add(b2);
        numbers.add(b3);
        numbers.add(b4);
        int randomInt = randomGenerator.nextInt(3);
        button5.setText(matchWordsList.get(numbers.remove(randomInt)).getWelsh());
        button5.setStyle("");
        randomInt = randomGenerator.nextInt(2);
        button6.setText(matchWordsList.get(numbers.remove(randomInt)).getWelsh());
        button6.setStyle("");
        randomInt = randomGenerator.nextInt(1);
        button7.setText(matchWordsList.get(numbers.remove(randomInt)).getWelsh());
        button7.setStyle("");
        randomInt = randomGenerator.nextInt(1);
        button8.setText(matchWordsList.get(numbers.remove(randomInt)).getWelsh());
        button8.setStyle("");


        //sets buttons clickable
        button1.setDisable(false);
        button2.setDisable(false);
        button3.setDisable(false);
        button4.setDisable(false);
        button5.setDisable(false);
        button6.setDisable(false);
        button7.setDisable(false);
        button8.setDisable(false);
    }


    /**
     * method that creates for objects words based on matchWordList
     * then it puts the words into two different hashmaps
     * it assigns user matches with 8 strings by receiving them from stack
     * and compares its english meaning using hashmaps so makes sure that answers are right or wrong
     */
    public void correctChecker() {

        Word m1 = new Word(matchWordsList.get(0).getEnglish(), matchWordsList.get(0).getWelsh(), matchWordsList.get(0).getType());
        Word m2 = new Word(matchWordsList.get(1).getEnglish(), matchWordsList.get(1).getWelsh(), matchWordsList.get(1).getType());
        Word m3 = new Word(matchWordsList.get(2).getEnglish(), matchWordsList.get(2).getWelsh(), matchWordsList.get(2).getType());
        Word m4 = new Word(matchWordsList.get(3).getEnglish(), matchWordsList.get(3).getWelsh(), matchWordsList.get(3).getType());

        //puts the 4 words into two hashmaps for further comparing
        hashMapEnglish.put(m1.getEnglish(), m1);
        hashMapEnglish.put(m2.getEnglish(), m2);
        hashMapEnglish.put(m3.getEnglish(), m3);
        hashMapEnglish.put(m4.getEnglish(), m4);
        hashMapWelsh.put(m1.getWelsh(), m1);
        hashMapWelsh.put(m2.getWelsh(), m2);
        hashMapWelsh.put(m3.getWelsh(), m3);
        hashMapWelsh.put(m4.getWelsh(), m4);

        //assign stacks variables to strings for comparing
        match1 = answers.pop();
        match2 = answers.pop();
        match3 = answers.pop();
        match4 = answers.pop();
        match5 = answers.pop();
        match6 = answers.pop();
        match7 = answers.pop();
        match8 = answers.pop();

        /**
         * if conditions for comparing users matches that been passed into hashmaps
         * if answers are correct then score is added
         * the words are compared based on containsKey method and after the english meanings are compared
         * if condition is true, score is incremented which means the user answered correctly
         */
        if (hashMapEnglish.containsKey(match2) && hashMapWelsh.containsKey(match1) || hashMapEnglish.containsKey(match1) && hashMapWelsh.containsKey(match2)) {
            if (hashMapEnglish.containsKey(match2)) {
                if (hashMapEnglish.get(match2).getEnglish().equals(hashMapWelsh.get(match1).getEnglish())) {
                    score++;
                }
            } else if (hashMapEnglish.containsKey(match1)) {
                if (hashMapEnglish.get(match1).getEnglish().equals(hashMapWelsh.get(match2).getEnglish())) {
                    score++;
                }
            }
        }
        if (hashMapEnglish.containsKey(match4) && hashMapWelsh.containsKey(match3) || hashMapEnglish.containsKey(match3) && hashMapWelsh.containsKey(match4)) {
            if (hashMapEnglish.containsKey(match4)) {
                if (hashMapEnglish.get(match4).getEnglish().equals(hashMapWelsh.get(match3).getEnglish())) {
                    score++;
                } else if (hashMapEnglish.containsKey(match3)) {
                    if (hashMapEnglish.get(match3).getEnglish().equals(hashMapWelsh.get(match4).getEnglish())) {
                        score++;
                    }
                } else {
                    System.out.println("wrong");
                }
            }
        }
        if (hashMapEnglish.containsKey(match6) && hashMapWelsh.containsKey(match5) || hashMapEnglish.containsKey(match5) && hashMapWelsh.containsKey(match6)) {
            if (hashMapEnglish.containsKey(match6)) {
                if (hashMapEnglish.get(match6).getEnglish().equals(hashMapWelsh.get(match5).getEnglish())) {


                    score++;
                }
            } else if (hashMapEnglish.containsKey(match5)) {
                if (hashMapEnglish.get(match5).getEnglish().equals(hashMapWelsh.get(match6).getEnglish())) {
                    score++;
                }
            } else {
                System.out.println("wrong");
            }
        }
        if (hashMapEnglish.containsKey(match8) && hashMapWelsh.containsKey(match7) || hashMapEnglish.containsKey(match7) && hashMapWelsh.containsKey(match8)) {
            if (hashMapEnglish.containsKey(match8)) {
                if (hashMapEnglish.get(match8).getEnglish().equals(hashMapWelsh.get(match7).getEnglish())) {
                    score++;
                } else if (hashMapEnglish.containsKey(match7)) {
                    if (hashMapEnglish.get(match7).getEnglish().equals(hashMapWelsh.get(match8).getEnglish())) {
                        score++;
                    }
                } else {
                    System.out.println("wrong");
                }
            }
        }
        words = words + 4; //number of matches are 4 so it's incremented by four
    }

    /**
     * method that keeps track of order of users answers and according to that it pushes the answer into stack
     * also changes the colors of buttons so the pairs of matches can be easily distinguished
     * and after it sets buttons on disable to prevent user from picking the same word more than once
     */
    public void buttonsMatch() {
        button1.setOnAction(e -> {
            button1.setDisable(true);
            answers.push(button1.getText());
            if (checker < 2) {
                button1.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button1.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button1.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button1.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button2.setOnAction(e -> {
            button2.setDisable(true);
            answers.push(button2.getText());
            if (checker < 2) {
                button2.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button2.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button2.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button2.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button3.setOnAction(e -> {

            button3.setDisable(true);
            answers.push(button3.getText());
            if (checker < 2) {
                button3.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button3.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button3.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button3.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button4.setOnAction(e -> {

            button4.setDisable(true);
            answers.push(button4.getText());
            if (checker < 2) {
                button4.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button4.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button4.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button4.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button5.setOnAction(e -> {

            button5.setDisable(true);
            answers.push(button5.getText());
            if (checker < 2) {
                button5.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button5.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button5.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button5.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button6.setOnAction(e -> {

            button6.setDisable(true);
            answers.push(button6.getText());
            if (checker < 2) {
                button6.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button6.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button6.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button6.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button7.setOnAction(e -> {

            button7.setDisable(true);
            answers.push(button7.getText());
            if (checker < 2) {
                button7.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button7.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button7.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button7.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
        button8.setOnAction(e -> {
            button8.setDisable(true);
            answers.push(button8.getText());
            if (checker < 2) {
                button8.setStyle("-fx-background-color: #06f27c");
            }
            if (checker >= 2 && checker < 4) {
                button8.setStyle("-fx-background-color: #FF6347");
            }
            if (checker >= 4 && checker < 6) {
                button8.setStyle("-fx-background-color: #BA55D3");
            }
            if (checker >= 6) {
                button8.setStyle("-fx-background-color: #DAA520");
            }
            checker++;
        });
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        updateTable();   //loads data
        assignButtons();    //assign words to buttons
        buttonsMatch(); //keeps track of answer orders and deals with colors and buttons settings
        showScore.setText("Your score: " + score + "/" + words); //sets default score
    }

}
