/**
 * @(#) PickTheWordController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */
package javafx;
/**
 * PickTheWordController - A controller class that allows user to do revision
 * of pick the correct word type.
 *
 * @author jas117
 * @author wos2
 */

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class PickTheWordController extends RevisionController implements Initializable {

    // //////////////// //
    // Class variables. //
    // //////////////// //


    int loopInt = 0;    //int variable that keeps that of indexes in array list
    public int words;   //int variable that  keeps that of number of questions
    public int score;   //int variable that keeps that of score
    public int language;    //int variable that is responsible for changing the main language
    public String answerr;  //String variable that is responsible for keeping the other language answer
    public HashMap<String, Word> hashMapFlashcards = new HashMap<>(); //hashmap for storing the words and preventing from repeated words
    public ArrayList<Word> flashcardsWords = new ArrayList<Word>(10); //arraylist for storing the words objects


    @FXML
    Text showScore;
    //sets up buttons fx ids for dealing with styles, color, getText
    @FXML
    Button answer1;
    @FXML
    Button answer2;
    @FXML
    Button answer3;
    @FXML
    Button answer4;
    @FXML
    Button answer5;
    @FXML
    Button answer6;
    @FXML
    Button answer7;
    @FXML
    Button answer8;

    @FXML
    Button englishPick;
    @FXML
    Button welshPick;


    // //////// //
    // Methods. //
    // //////// //


    //functions required for changing the main language
    public void setEnglishLanguage() {
        language = 0;
        System.out.println(language);
    }

    public void setWelshLanguage() {
        language = 1;
        System.out.println(language);
    }

    /**
     * @throws IOException method that checks if the user answer is correct and depends on that changes
     *                     the colors of button giving positive and negative feedback on that
     */
    @FXML
    public void check14(ActionEvent event) throws IOException {
        if (answerr.equals(answer4.getText())) {
            score++;
            words++;
            answer4.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {
                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer5.getText())) {
                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer6.getText())) {
                words++;
                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer7.getText())) {
                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            words++;
            System.out.println("wrong");
        }

        buttonsDisable();
    }

    /**
     * @throws IOException method that checks if the user answer is correct and depends on that changes
     *                     the colors of button giving positive and negative feedback on that
     */
    @FXML
    public void check12() throws IOException {
        if (answerr.equals(answer2.getText())) {
            answer2.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");
            score++;
            words++;
            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {

                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer5.getText())) {

                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            if (answerr.equals(answer7.getText())) {
                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            words++;
            System.out.println("wrong");
        }

        buttonsDisable();
    }

    /**
     * @throws IOException method that checks if the user answer is correct and depends on that changes
     *                     the colors of button giving positive and negative feedback on that
     */
    @FXML
    public void check13() throws IOException {
        if (answerr.equals(answer3.getText())) {

            words++;
            score++;
            answer3.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            System.out.println("git");
        } else {
            if (answerr.equals(answer2.getText())) {

                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer3.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
//                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer5.getText())) {

                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }

            if (answerr.equals(answer7.getText())) {

                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            System.out.println("wrong");
            words++;
        }

        buttonsDisable();
    }

    /**
     * @throws IOException method that checks if the user answer is correct and depends on that changes
     *                     the colors of button giving positive and negative feedback on that
     */
    @FXML
    public void check15() throws IOException {
        if (answerr.equals(answer5.getText())) {
            answer5.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            words++;
            score++;
            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {

                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer6.getText())) {

                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer7.getText())) {

                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            words++;
            System.out.println("wrong");
        }
        buttonsDisable();
    }

    /**
     * @throws IOException method that checks if the user answer is correct and depends on that changes
     *                     the colors of button giving positive and negative feedback on that
     */
    @FXML
    public void check16() throws IOException {
        if (answerr.equals(answer6.getText())) {

            words++;
            score++;
            answer6.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");
            answer7.setStyle("-fx-background-color:#f23106");

            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {
                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer4.getText())) {

                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer5.getText())) {

                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer7.getText())) {
                answer7.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            }
            System.out.println("wrong");
            words++;
        }
        buttonsDisable();
    }

    /**
     * @throws IOException method that checks if the user answer is correct and depends on that changes
     *                     the colors of button giving positive and negative feedback on that
     */
    @FXML
    public void check17() throws IOException {
        if (answerr.equals(answer7.getText())) {
            answer7.setStyle("-fx-background-color:#06f27c");
            answer1.setStyle("-fx-background-color:#06f27c");
            answer3.setStyle("-fx-background-color:#f23106");
            answer4.setStyle("-fx-background-color:#f23106");
            answer5.setStyle("-fx-background-color:#f23106");
            answer6.setStyle("-fx-background-color:#f23106");
            answer2.setStyle("-fx-background-color:#f23106");

            words++;
            score++;
            System.out.println("git");
        } else {
            if (answerr.equals(answer3.getText())) {
                answer3.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");
            } else if (answerr.equals(answer4.getText())) {
                answer4.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");
            } else if (answerr.equals(answer5.getText())) {
                answer5.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer6.getText())) {
                answer6.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
                answer2.setStyle("-fx-background-color:#f23106");

            } else if (answerr.equals(answer2.getText())) {
                answer2.setStyle("-fx-background-color:#06f27c");
                answer1.setStyle("-fx-background-color:#06f27c");
                answer3.setStyle("-fx-background-color:#f23106");
                answer4.setStyle("-fx-background-color:#f23106");
                answer5.setStyle("-fx-background-color:#f23106");
                answer6.setStyle("-fx-background-color:#f23106");
                answer7.setStyle("-fx-background-color:#f23106");
            }
            words++;
            System.out.println("wrong");
        }
        buttonsDisable();
    }

    //method called in checks that sets buttons not clickable
    public void buttonsDisable() throws IOException {

        answer1.setDisable(true);
        answer2.setDisable(true);
        answer3.setDisable(true);
        answer4.setDisable(true);
        answer5.setDisable(true);
        answer6.setDisable(true);
        answer7.setDisable(true);
    }

    //method called in checks that sets buttons clickable
    public void buttonsEnable() throws IOException {

        answer1.setDisable(false);
        answer2.setDisable(false);
        answer3.setDisable(false);
        answer4.setDisable(false);
        answer5.setDisable(false);
        answer6.setDisable(false);
        answer7.setDisable(false);
    }

    /**
     * @throws IOException method that clears hashmaps, sets loopInt = 0 for keeping track of indexes in new set of words
     *                     calls another methods
     *                     and checks if desired main language has changed and if yes it changes the way it displays
     */

    @FXML
    public void newSet() throws IOException {
        hashMapFlashcards.clear();
        loopInt = 0;
        resetButtonStyles();
        buttonsEnable();
        updateTable();
        int x = (int) getRandomIntegerBetweenRange(0, 5);
        if (language == 0) {
            answerr = flashcardsWords.get(x).getEnglish();
            answer1.setText(flashcardsWords.get(x).getWelsh());
        } else if (language == 1) {
            answerr = flashcardsWords.get(x).getWelsh();
            answer1.setText(flashcardsWords.get(x).getEnglish());
        }
        assignAnswers();
        showScore.setText("Your score: " + score + "/" + words);
    }

    //resets the button styles
    private void resetButtonStyles() {
        answer1.setStyle("");
        answer2.setStyle("");
        answer3.setStyle("");
        answer4.setStyle("");
        answer5.setStyle("");
        answer6.setStyle("");
        answer7.setStyle("");

    }

    //method to change scene to help scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    //method to change scene to home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    //method to change scene to revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    //method to change scene to add word scene
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    //method to get random int
    public static double getRandomIntegerBetweenRange(double min, double max) {
        int x = (int) ((Math.random() * ((max - min) + 1)) + min);
        return x;
    }

    /**
     * submit method that checks is all buttons has been matched
     * checks for right answer by calling correctChecker(), updates table (data) and assigns button new answers
     * in case of not each word has been clicked (matched) it pops up error message explaining user's mistake
     * does all of it under consideration of main language
     */
    public void updateTable() {
        flashcardsWords.clear();
        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        try {
            dictionary.load(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {

                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));

            }
        }
        Random random = new Random();
        if (language == 0) {
            while (!(flashcardsWords.size() == 7)) {
                Word w = data.get(random.nextInt(data.size()));
                if (!hashMapFlashcards.containsValue(w)) {
                    hashMapFlashcards.put(w.getEnglish(), w);
                    flashcardsWords.add(loopInt, w);
                    loopInt++;
                }

            }
        } else if (language == 1) {
            while (!(flashcardsWords.size() == 7)) {
                Word w = data.get(random.nextInt(data.size()));
                if (!hashMapFlashcards.containsValue(w)) {
                    hashMapFlashcards.put(w.getWelsh(), w);
                    flashcardsWords.add(loopInt, w);
                    loopInt++;
                }

            }
        }
    }


    //method that assigns answers to button texts
    public void assignAnswers() {
        if (language == 0) {
            answer6.setText(flashcardsWords.get(0).getEnglish());
            answer2.setText(flashcardsWords.get(1).getEnglish());
            answer3.setText(flashcardsWords.get(2).getEnglish());
            answer4.setText(flashcardsWords.get(3).getEnglish());
            answer5.setText(flashcardsWords.get(4).getEnglish());
            answer7.setText(flashcardsWords.get(5).getEnglish());
            for (int i = 0; i < 6; i++) {
                System.out.println(flashcardsWords.get(i).getEnglish());
            }
        } else if (language == 1) {
            answer6.setText(flashcardsWords.get(0).getWelsh());
            answer2.setText(flashcardsWords.get(1).getWelsh());
            answer3.setText(flashcardsWords.get(2).getWelsh());
            answer4.setText(flashcardsWords.get(3).getWelsh());
            answer5.setText(flashcardsWords.get(4).getWelsh());
            answer7.setText(flashcardsWords.get(5).getWelsh());
            for (int i = 0; i < 6; i++) {
                System.out.println(flashcardsWords.get(i).getWelsh());
            }


        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //default score is set up wit its style too
        showScore.setText("Your score: " + score + "/" + words);
        showScore.setStyle("-fx-background-color:#80ced6");
        updateTable();
        int x = (int) getRandomIntegerBetweenRange(0, 5);

        //checks for main language and based on that assigns displayed words
        if (language == 0) {
            answerr = flashcardsWords.get(x).getEnglish();
            answer1.setText(flashcardsWords.get(x).getWelsh());
            assignAnswers();
        } else if (language == 1) {
            answerr = flashcardsWords.get(x).getWelsh();
            answer1.setText(flashcardsWords.get(x).getEnglish());
            assignAnswers();
        }
    }
}