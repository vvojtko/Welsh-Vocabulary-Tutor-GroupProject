/**
 * @(#) RevisionController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package javafx;
/**
 * RevisionController - A controller class that allows user to pick to do
 * 4 types of revisions and checks if it's possible depends on number of words in
 * practise list.
 * @author wos2
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.ResourceBundle;

public class RevisionController extends HomeController implements Initializable {

    public ArrayList<Word> favouritesWords = new ArrayList<Word>(); //arraylist for making sure user may run the tests if required number of words is in there

    @FXML
    TextField textField;
    @FXML
    ImageView imageView;
    @FXML
    ImageView imageView2;
    @FXML
    ImageView imageView3;
    @FXML
    ImageView imageView4;


    //sets images for image view
    private Image image = new Image(getClass().getResource("matchthwords.png").toExternalForm());
    private Image image2 = new Image(getClass().getResource("pick.png").toExternalForm());
    private Image image3 = new Image(getClass().getResource("test.png").toExternalForm());
    private Image image4 = new Image(getClass().getResource("flashcards.png").toExternalForm());


    // //////// //
    // Methods. //
    // //////// //


    //loads data into array list json file through hashmultimap
    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        try {
            dictionary.load(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        favouritesWords.addAll(data);

    }

    //method to change scene for help scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    //method to change scene for home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    //method to change scene for revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    //method to change scene for add word scene
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }

    //method to change scene for match scene checking if practise words lists contains enough words to run it
    @FXML
    public void changeScreenToMatch(ActionEvent event) throws IOException {
        if (favouritesWords.size() < 9) {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You don't have enough words to do this revision.\n" +
                    "Your practise list has to contain at least 8 words!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        } else {
            Main.showMatch();
        }
    }


    //method to change scene for pick the word scene checking if practise words lists contains enough words to run it
    @FXML
    public void changeScreenToPick(ActionEvent event) throws IOException {
        if (favouritesWords.size() < 6) {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You don't have enough words to do this revision.\n" +
                    "Your practise list has to contain at least 6 words!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        } else {
            Main.showPick();
        }
    }

    //method to change scene for test scene
    @FXML
    public void changeScreenToTest(ActionEvent event) throws IOException {
        Main.showTest();
    }

    //method to change scene for flashcards scene
    @FXML
    public void changeScreenToFlashcards(ActionEvent event) throws IOException {
        Main.showFlashcards();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        updateTable();

        //sets images on image views
        imageView.setImage(image);

        imageView2.setImage(image2);

        imageView3.setImage(image3);

        imageView4.setImage(image4);

    }
}
