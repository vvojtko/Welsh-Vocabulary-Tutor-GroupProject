/**
 * @(#) TestController.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */
package javafx;
/**
 * TestController - A controller class that allows user to do revision
 * of test type.
 * @author jas117
 * @author wos2
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import main.Dictionary;
import main.Word;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.*;

public class TestController extends FlashcardsController implements Initializable {

    // //////////////// //
    // Class variables. //
    // //////////////// //

    int rightAnswer = 2;    //int variable for keeping the number (index) of right answer
    public HashMap<String, Word> flashcardsWordsMap = new HashMap<>();  //hashmap for storing words for test and prevent repeated words
    public ArrayList<Word> testWords = new ArrayList<Word>(10); //list for storing words


    int counter = 0;    //int variable for keeping track of current question
    int words = 0;  //int variable for keeping track of number of questions
    int language = 1;   //int variable for main language set
    int score = 0;  //int variable for keeping track of current score

    public String eng = ""; //string variable for getting a word english meaning

    //sets up fx ids for buttons and text, text fields
    @FXML
    Button submit;
    @FXML
    TextField textField;
    @FXML
    Text rightAnswerr;
    @FXML
    Text showScore;
    @FXML
    TextField answer;

    /**
     * @throws IOException method that is responsible for dealing with button displaying and getting a new word
     *                     for test from array list and pops up a error message explaining that user ran out from practise words
     */
    @FXML
    public void next() throws IOException {
        submit.setDisable(false);
        if (counter < testWords.size() - 1) {
            counter++;
            textField.setStyle("-fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
            answer.setStyle("");

            //checks for language and based on that it assigns proper translated word on textfield
            if (language == 0) {
                textField.setText(testWords.get(counter).getEnglish());
            } else if (language == 1) {
                textField.setText(testWords.get(counter).getWelsh());
            }
        } else {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You ran out of test words! \nRun tests again or go to next one!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        }
        showRightAnswer();  //shows right answer
    }

    /**
     * method that checks user answer and compare it with correct answer
     * based on that it changes the colors giving the positive or negative feedback
     * sets button after clicked disabled and pops up error message if user ran out of
     * practise words list
     *
     * @throws IOException
     */
    @FXML
    public void submit() throws IOException {
        if (counter < data.size() - 1) {
            eng = answer.getText();
            eng = eng.toLowerCase();
            if (language == 0) {
                if (eng.equals(testWords.get(counter).getWelsh().toLowerCase())) {
                    words++;
                    score++;
                    textField.setStyle("-fx-background-color: green; -fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
                    answer.setStyle("-fx-background-color: green;");

                } else {
                    rightAnswer = 1;
                    //       showRightAnswer();
                    words++;
                    textField.setStyle("-fx-background-color: red; -fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
                    answer.setStyle("-fx-background-color: red;");
                }
            }
            if (language == 1) {
                if (eng.equals(testWords.get(counter).getEnglish().toLowerCase())) {
                    words++;
                    score++;
                    textField.setStyle("-fx-background-color: green; -fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
                    answer.setStyle("-fx-background-color: green;");

                } else {
                    rightAnswer = 1;
                    //     showRightAnswer();
                    words++;
                    textField.setStyle("-fx-background-color: red; -fx-alignment: Center; -fx-font-size: 30pt; -fx-font-weight: bold; -fx-text-inner-color: grey;");
                    answer.setStyle("-fx-background-color: red;");
                }
            }
            submit.setDisable(true);

            showRightAnswer();
            showScore.setText("Your score: " + score + "/" + words);
        } else {
            final Stage dialog = new Stage();
            VBox dialogVbox = new VBox(20);
            Text text = new Text(("You ran out of practise list words!\n" +
                    "Run other test or add new words!"));
            dialogVbox.getChildren().add(text);
            text.setTextAlignment(TextAlignment.CENTER);
            Scene dialogScene = new Scene(dialogVbox, 450, 50);
            dialog.setScene(dialogScene);
            dialog.show();
        }
    }

    //method to change scene to help scene
    @FXML
    public void changeScreenToHelp(ActionEvent event) throws IOException {
        Main.showHelp();
    }

    //method to change scene to home scene
    @FXML
    public void changeScreenToHome(ActionEvent event) throws IOException {
        Main.showHome();
    }

    //method to change scene to revision scene
    @FXML
    public void changeScreenToRevision(ActionEvent event) throws IOException {
        Main.showRevision();
    }

    //method to change scene to add word scene
    @FXML
    public void changeScreenToAddWord(ActionEvent event) throws IOException {
        Main.showAdd();
    }


    //method working on int variable giving the feedback on input called after user answered
    public void showRightAnswer() {
        if (rightAnswer == 1) {
            rightAnswerr.setVisible(true);
            if (language == 0) {
                rightAnswerr.setText("Correct answer: " + testWords.get(counter).getWelsh());
            } else if (language == 1) {
                rightAnswerr.setText("Correct answer: " + testWords.get(counter).getEnglish());
            }
            rightAnswer = 2;
        } else if (rightAnswer == 2) {
            rightAnswerr.setVisible(false);
        }
    }

    //sets the main language on English
    public void setEnglishLanguage() {
        language = 0;
        counter = 0;
        System.out.println(language);
    }

    //sets the main language on Welsh
    public void setWelshLanguage() {
        language = 1;
        counter = 0;
        System.out.println(language);
    }

    /**
     * this function is just loading data into list data list
     * then it puts it into testWords arraylist on which buttons and meanings works,
     * and puts it also into flashcardsWordsMap which is responsible for avoiding repeated answers
     */
    public void updateTable() {

        Dictionary dictionary = new Dictionary();
        //here of course has to be proper path for dictionary.json depends on your pc
        try {
            dictionary.load(filePathToPractiseList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        dictionaryMap = dictionary.export();
        for (Map.Entry<String, Word> entry : dictionaryMap.entries()) {
            Word word = entry.getValue();
            String wt = word.getType();
            if (wt == null) {
                data.add(new Word(word.getEnglish(), word.getWelsh(), "other"));
            } else {
                data.add(new Word(word.getEnglish(), word.getWelsh(), wt));
            }
        }
        Random random = new Random();
        int loopInt = 0;

        //runs while gets all practise list from data and add it into testWords
        while (!(testWords.size() == data.size())) {
            Word w = data.get(random.nextInt(data.size()));
            if (!flashcardsWordsMap.containsValue(w)) { //checks for repeated words to avoid them
                flashcardsWordsMap.put(w.getEnglish(), w);
                testWords.add(loopInt, w);
                loopInt++;
            }
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        updateTable();
        if (language == 0) {
            textField.setText(testWords.get(counter).getEnglish());
        } else if (language == 1) {
            textField.setText(testWords.get(counter).getWelsh());
        }
        showScore.setText("Your score: " + score + "/" + words);
        showRightAnswer();
    }
}