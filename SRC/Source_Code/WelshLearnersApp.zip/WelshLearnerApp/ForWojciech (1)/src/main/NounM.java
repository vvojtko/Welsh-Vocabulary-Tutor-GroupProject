/**
 * @(#) NounM.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package main;

/**
 * This class represents the Male Nouns of the database storing the
 * necessary data. Extends Word.
 * <p>
 * Is used by creating a NounM object.
 *
 * @author jas117
 * @author wos2
 * @author jab167
 * @version 1.0
 * @see Word
 */


public class NounM
        extends Word {

    // ///////////// //
    // Constructors. //
    // ///////////// //

    public NounM() {
        super();
    }

    public NounM(String welsh, String english, String wordType) {
        super(welsh, english, wordType);
    }

    // //////// //
    // Methods. //
    // //////// //

    /**
     * Returns a String that allows to
     * identify the class of the object.
     *
     * @return the string "nm".
     */
    @Override
    public String getType() {
        return "nm";
    }

    /**
     * Returns the Welsh meaning stored.
     *
     * @return welsh.
     * @see Word
     */
    @Override
    public String getWelsh() {
        return super.getWelsh();
    }

    /** Returns the English meaning stored.
     *
     * @return english.
     * @see Word
     */

    @Override
    public String getEnglish() {
        return super.getEnglish();
    }

    /**Allows us to set the value for
     * welsh.
     *
     *
     * @param welsh string that will be set as the meaning.
     * @see Word
     */

    @Override
    public void setWelsh(String welsh) {
        super.setWelsh(welsh);
    }

    /**
     * Allows us to set the value for
     * english.
     *
     * @param english string that will be set as the meaning.
     * @see Word
     */

    @Override
    public void setEnglish(String english) {
        super.setEnglish(english);
    }

    /**
     * This functions returns the English and Welsh
     * meanings and the word type in for of String.
     *
     * @return the info contained in the object.
     */

    @Override
    public String toString() {
        return super.toString();
    }
}