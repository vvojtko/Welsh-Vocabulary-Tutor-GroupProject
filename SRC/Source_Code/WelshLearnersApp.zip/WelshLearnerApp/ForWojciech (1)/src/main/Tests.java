/**
 * @(#) Tests.java 1.0 2020/06/01
 * <p>
 * Copyright (c) 2020 Aberystwyth University.
 * All rights reserved.
 */

package main;

import org.json.simple.parser.ParseException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * A class that contains four Junit tests for testing the program
 * There is a test for the loading of the json file,
 * a test for searching for a specific word in the json file,
 * a test that adds a new word to the json file and then searches for said word,
 * and a test that adds one word of each type (verb, noun male, noun female and 'other')
 * and then checks if all four words were added to the json file
 *
 * @author jas117
 * @author vad7
 * @author ars21
 * @version 1.0 all tests work
 * @see Dictionary
 */

public class Tests {

    Dictionary dictionary = new Dictionary();
    String filePathToDictionary = "C:\\Users\\andra\\Desktop\\WelshLearnerAppV4.20\\ForWojciech (1)\\src\\main\\dictionary.json";

    /**
     * Loads the json file and checks for FileNotFoundException, ParseException, IOException and Exception.
     * @see Dictionary
     */
    @Test
    public void loadingTest() {
        boolean thrown = false;

        try {
            dictionary.load("fakepath");
            Assertions.fail("Didn't throw even if the file path doesnt exists");
        } catch (FileNotFoundException e) {
            thrown = true;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Assertions.assertTrue(thrown);
    }

    /**
     * Searches for a specific word with translation and type in the json file
     * and checks if the result is correct.
     * @see Dictionary
     */
    @Test
    public void searchingTest() {
        try {
            dictionary.load(filePathToDictionary);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


        Assertions.assertEquals("Word{welsh='Unol Daleithiau ', english='United States ', wordType='other'}",
                dictionary.findWordInEnglishDeveloper("United States "));

        Assertions.assertEquals("Word{welsh='Unol Daleithiau ', english='United States ', wordType='other'}",
                dictionary.findWordInWelshDeveloper("Unol Daleithiau "));
    }

    /**
     * Adds a word to the dictionary, then searches for it
     * both from the Welsh and English Meanings, checking
     * if the results are correct.
     *
     * @see Dictionary
     */
    @Test
    public void addAndSearchTest() {
        dictionary.storeNewWordDeveloper("Sample English Meaning", "Sample Welsh Meaning", "other");

        Assertions.assertEquals("Word{welsh='Sample Welsh Meaning', english='Sample English Meaning', wordType='other'}",
                dictionary.findWordInWelshDeveloper("Sample Welsh Meaning"));
    }

    /**
     * Adds a word of each type to the dictionary, then searches for said words,
     * checking that all types of words can be created and that the results
     * are correct.
     * @see Dictionary
     */
    @Test
    public void testAllWordTypes() {

        // Iterates through a switch statement
        for (int i = 0; i < 4; i++) {
            switch (i) {

                // Adds and searches for a verb
                case 0:
                    dictionary.storeNewWordDeveloper("Example English Verb", "Example Welsh Verb", "v");
                    Assertions.assertEquals("Word{welsh='Example Welsh Verb', english='Example English Verb', wordType='v'}",
                            dictionary.findWordInEnglishDeveloper("Example English Verb"));
                    break;

                // Adds nd searches for a masculin noun
                case 1:
                    dictionary.storeNewWordDeveloper("Example English Masculine Noun", "Example Welsh Masculine Noun", "nm");
                    Assertions.assertEquals("Word{welsh='Example Welsh Masculine Noun', english='Example English Masculine Noun', wordType='nm'}",
                            dictionary.findWordInEnglishDeveloper("Example English Masculine Noun"));
                    break;

                // Adds and searches for a feminine noun
                case 2:
                    dictionary.storeNewWordDeveloper("Example English Feminine Noun", "Example Welsh Feminine Noun", "nf");
                    Assertions.assertEquals("Word{welsh='Example Welsh Feminine Noun', english='Example English Feminine Noun', wordType='nf'}",
                            dictionary.findWordInEnglishDeveloper("Example English Feminine Noun"));
                    break;

                // Adds and searches for a 'other' word
                case 3:
                    dictionary.storeNewWordDeveloper("Example English Word", "Example Welsh Word", "other");
                    Assertions.assertEquals("Word{welsh='Example Welsh Word', english='Example English Word', wordType='other'}",
                            dictionary.findWordInEnglishDeveloper("Example English Word"));
                    break;
            }
        }
    }


}