/**
 * @(#) Word.java 1.8 2020/05/01
 * <p>
 * Copyright (c) 2016 Aberystwyth University.
 * All rights reserved.
 */

package main;

/**
 * This is the base for all the objects that represent the words in the database.
 *
 * <p>
 * This class is not used, since the classes that extend from this class are the
 * ones that are used to represents the words.
 *
 * @author jas117
 * @author wos2
 * @author jab167
 * @version 1.0
 * @see java.lang.Comparable
 */

import java.util.Objects;

public class Word implements Comparable<Word> {

    // /////////////////// //
    // Instance variables. //
    // /////////////////// //


    private String welsh;
    private String english;
    private String wordType;

    // ///////////// //
    // Constructors. //
    // ///////////// //

    public Word() {

    }

    public Word(String englishMeaning, String welshMeaning, String wordType) {
        this.english = englishMeaning;
        this.welsh = welshMeaning;
        this.wordType = wordType;
    }

    // //////// //
    // Methods. //
    // //////// //

    /**
     * Returns wordType.
     *
     * @return wordType.
     *
     */

    public String getType() {
        return wordType;
    }

    /**
     * Returns welsh.
     *
     * @return welsh.
     *
     */

    public String getWelsh() {
        return welsh;
    }

    /**
     * Returns english.
     *
     * @return english.
     *
     */

    public String getEnglish() {
        return english;
    }

    /**
     * Allows us to set the value for
     * welsh.
     *
     * @param welsh string that will be set as the meaning.
     */

    public void setWelsh(String welsh) {
        this.welsh = welsh;
    }

    /**
     * Allows us to set the value for
     * english.
     *
     * @param english string that will be set as the meaning.
     */

    public void setEnglish(String english) {
        this.english = english;
    }

    /**Sets up a hash code for word object.
     *
     * @return hash code.
     */
    @Override
    public int hashCode() {
        return Objects.hash(welsh, english, wordType);
    }

    /**This command compares the two english meanings of
     * two words objects and returns 1,0,-1 based on which one
     * comes first alphabetically.
     *
     * @param o the second word object the first one is compared to.
     * @return 1,-1,0
     */

    public int compareTo(Word o) {
        return this.getEnglish().compareTo(o.getEnglish());
    }

    /**This functions checks if two Words objects are exactly the
     * same, comparing the welsh, english and welsh and returning
     * true if they all match.
     *
     * @param o the second word object the first one is compared to.
     * @return True or False.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Word word = (Word) o;
        return Objects.equals(welsh, word.welsh) &&
                Objects.equals(english, word.english) &&
                Objects.equals(wordType, word.wordType);
    }

    /**
     * This functions returns the English and Welsh
     * meanings and the word type in for of String.
     *
     * @return the info contained in the object.
     */

    @Override
    public String toString() {
        return "Word{" +
                "welsh='" + welsh + '\'' +
                ", english='" + english + '\'' +
                ", wordType='" + getType() + '\'' +
                '}';
    }
}